const headerTimeEl = document.getElementById("headerTime");
const runStatusEl = document.getElementById("runStatus");
const profileLabelEl = document.getElementById("profileLabel");
const filtersEl = document.getElementById("filters");
const tipCategoryEl = document.getElementById("tipCategory");
const tipTitleEl = document.getElementById("tipTitle");
const tipBodyEl = document.getElementById("tipBody");
const tipMetaEl = document.getElementById("tipMeta");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const regenBtn = document.getElementById("regenBtn");
const accountabilityBtn = document.getElementById("accountabilityBtn");
const eyesStageEl = document.getElementById("eyesStage");
const eyesHintEl = document.getElementById("eyesHint");

const PROFILE_LABELS = {
  atiLesson: "ATI Lesson",
  videoCase: "Video Case",
  assessment: "Assessment",
  popupCase: "Popup Case"
};

const CATEGORY_LABELS = Object.fromEntries(
  (globalThis.FoxStudyTips?.STUDY_TIP_CATEGORIES || []).map((c) => [c.id, c.label])
);

let activeCategory = "all";
let deck = [];
let index = 0;
let pollTimer = null;
let eyesAnimId = null;
let accountabilityOn = false;

const eyeEls = Array.from(document.querySelectorAll(".cartoon-eye"));
const EYE_SMOOTHING = 0.24;
const EYE_MAX_RADIUS = 16;
const eyeStates = [];

function initEyeStates() {
  eyeStates.length = 0;
  for (const eyeEl of eyeEls) {
    eyeStates.push({
      px: 0,
      py: 0,
      targetPx: 0,
      targetPy: 0,
      pupil: eyeEl.querySelector(".pupil"),
      ball: eyeEl.querySelector(".eyeball")
    });
  }
}

initEyeStates();

function send(type, payload = {}) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage({ type, ...payload }, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else resolve(resp);
      });
    } catch (e) {
      reject(e);
    }
  });
}

function formatMs(ms) {
  const totalSec = Math.max(0, Math.ceil(Number(ms || 0) / 1000));
  const mins = Math.floor(totalSec / 60);
  const sec = totalSec % 60;
  return `${mins}:${String(sec).padStart(2, "0")}`;
}

function rebuildDeck({ preferRandom = false } = {}) {
  const tips = globalThis.FoxStudyTips?.tipsForCategory(activeCategory) || [];
  deck = tips.slice();
  if (!deck.length) {
    index = 0;
    renderTip();
    return;
  }
  if (preferRandom) {
    index = Math.floor(Math.random() * deck.length);
  } else {
    index = Math.min(index, deck.length - 1);
  }
  renderTip();
}

function renderFilters() {
  if (!filtersEl) return;
  const cats = globalThis.FoxStudyTips?.STUDY_TIP_CATEGORIES || [];
  filtersEl.innerHTML = "";
  for (const cat of cats) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "chip" + (cat.id === activeCategory ? " is-active" : "");
    btn.textContent = cat.label;
    btn.setAttribute("role", "tab");
    btn.setAttribute("aria-selected", cat.id === activeCategory ? "true" : "false");
    btn.addEventListener("click", () => {
      activeCategory = cat.id;
      renderFilters();
      rebuildDeck({ preferRandom: true });
    });
    filtersEl.appendChild(btn);
  }
}

function renderTip() {
  if (!deck.length) {
    if (tipCategoryEl) tipCategoryEl.textContent = "Tips";
    if (tipTitleEl) tipTitleEl.textContent = "No tips in this filter";
    if (tipBodyEl) tipBodyEl.textContent = "Try another topic or tap New tip.";
    if (tipMetaEl) tipMetaEl.textContent = "";
    return;
  }
  const tip = deck[index];
  if (tipCategoryEl) tipCategoryEl.textContent = CATEGORY_LABELS[tip.category] || tip.category;
  if (tipTitleEl) tipTitleEl.textContent = tip.title;
  if (tipBodyEl) tipBodyEl.textContent = tip.body;
  if (tipMetaEl) tipMetaEl.textContent = `${index + 1} of ${deck.length}`;
}

function step(delta) {
  if (!deck.length) return;
  index = (index + delta + deck.length) % deck.length;
  renderTip();
}

function regenerate() {
  if (!deck.length) {
    rebuildDeck({ preferRandom: true });
    return;
  }
  if (deck.length === 1) {
    renderTip();
    return;
  }
  let next = index;
  while (next === index) {
    next = Math.floor(Math.random() * deck.length);
  }
  index = next;
  renderTip();
}

function renderStatus(status) {
  const profile = PROFILE_LABELS[status?.settings?.contentProfile] || "";
  if (profileLabelEl) profileLabelEl.textContent = profile;

  if (!status?.running) {
    if (headerTimeEl) headerTimeEl.textContent = "--:--";
    if (runStatusEl && !accountabilityOn) {
      runStatusEl.textContent = "Timer idle — tips still work anytime.";
    }
    return;
  }

  const remaining = formatMs(status.remainingMs);
  if (headerTimeEl) headerTimeEl.textContent = remaining;
  if (runStatusEl && !accountabilityOn) {
    runStatusEl.textContent = status.paused
      ? `Paused · ${remaining} left`
      : `Running · ${remaining} left`;
  }
}

async function refreshStatus() {
  try {
    const resp = await send("LHT_GET_STATUS");
    if (resp?.ok) renderStatus(resp.status);
  } catch {
    // Companion can still show tips if messaging is briefly unavailable.
  }
}

function eyeScreenCenter(ball) {
  if (!ball) return { x: 0, y: 0 };
  const rect = ball.getBoundingClientRect();
  return {
    x: (window.screenX || 0) + rect.left + rect.width / 2,
    y: (window.screenY || 0) + rect.top + rect.height / 2
  };
}

function pupilOffsetForScreen(screenX, screenY, ball) {
  const center = eyeScreenCenter(ball);
  const dx = screenX - center.x;
  const dy = screenY - center.y;
  const dist = Math.hypot(dx, dy);
  if (dist < 0.5) return { px: 0, py: 0 };
  const radius = Math.min(EYE_MAX_RADIUS, dist / 6.5);
  return { px: (dx / dist) * radius, py: (dy / dist) * radius };
}

function setMouseTarget(screenX, screenY) {
  for (const state of eyeStates) {
    const off = pupilOffsetForScreen(screenX, screenY, state.ball);
    state.targetPx = off.px;
    state.targetPy = off.py;
  }
}

function resetEyePositions() {
  for (const state of eyeStates) {
    state.px = 0;
    state.py = 0;
    state.targetPx = 0;
    state.targetPy = 0;
    if (state.pupil) state.pupil.style.transform = "translate3d(0, 0, 0)";
  }
}

function tickEyes() {
  if (!accountabilityOn) return;
  for (const state of eyeStates) {
    state.px += (state.targetPx - state.px) * EYE_SMOOTHING;
    state.py += (state.targetPy - state.py) * EYE_SMOOTHING;
    if (state.pupil) {
      state.pupil.style.transform = `translate3d(${state.px}px, ${state.py}px, 0)`;
    }
  }
  eyesAnimId = requestAnimationFrame(tickEyes);
}

function startEyeLoop() {
  if (eyesAnimId) return;
  eyesAnimId = requestAnimationFrame(tickEyes);
}

function stopEyeLoop() {
  if (eyesAnimId) {
    cancelAnimationFrame(eyesAnimId);
    eyesAnimId = null;
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type !== "LHT_MOUSE_POS_PUSH" || !accountabilityOn) return;
  setMouseTarget(Number(msg.screenX) || 0, Number(msg.screenY) || 0);
});

document.addEventListener("mousemove", (e) => {
  if (!accountabilityOn) return;
  setMouseTarget(e.screenX, e.screenY);
}, { passive: true });

function resetAccountabilityUi() {
  accountabilityOn = false;
  if (accountabilityBtn) {
    accountabilityBtn.classList.remove("is-on");
    accountabilityBtn.textContent = "Accountability mode";
  }
  if (eyesStageEl) {
    eyesStageEl.classList.remove("is-visible");
    eyesStageEl.setAttribute("aria-hidden", "true");
  }
  if (eyesHintEl) eyesHintEl.classList.remove("is-visible");
  stopEyeLoop();
  resetEyePositions();
}

async function setAccountability(on) {
  if (!on) {
    resetAccountabilityUi();
    try {
      await send("LHT_SET_ACCOUNTABILITY", { enabled: false });
    } catch {
      // ignore
    }
    refreshStatus();
    return;
  }

  accountabilityOn = true;
  if (accountabilityBtn) {
    accountabilityBtn.classList.add("is-on");
    accountabilityBtn.textContent = "Turn off accountability";
  }
  if (eyesStageEl) {
    eyesStageEl.classList.add("is-visible");
    eyesStageEl.setAttribute("aria-hidden", "false");
  }
  if (eyesHintEl) eyesHintEl.classList.add("is-visible");
  if (runStatusEl) runStatusEl.textContent = "Watching your ATI tab…";

  try {
    const resp = await send("LHT_SET_ACCOUNTABILITY", { enabled: true });
    if (!resp?.ok) {
      resetAccountabilityUi();
      if (runStatusEl) {
        runStatusEl.textContent = resp?.error || "Open an ATI page first.";
      }
      return;
    }
    startEyeLoop();
  } catch (err) {
    resetAccountabilityUi();
    if (runStatusEl) runStatusEl.textContent = err?.message || String(err);
  }
}

accountabilityBtn?.addEventListener("click", () => {
  setAccountability(!accountabilityOn);
});

prevBtn?.addEventListener("click", () => step(-1));
nextBtn?.addEventListener("click", () => step(1));
regenBtn?.addEventListener("click", regenerate);

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft") step(-1);
  if (e.key === "ArrowRight") step(1);
  if (e.key === "r" || e.key === "R") regenerate();
});

renderFilters();
rebuildDeck({ preferRandom: true });
refreshStatus();
pollTimer = setInterval(refreshStatus, 1000);

window.addEventListener("beforeunload", () => {
  if (pollTimer) clearInterval(pollTimer);
  stopEyeLoop();
  if (accountabilityOn) {
    send("LHT_SET_ACCOUNTABILITY", { enabled: false }).catch(() => {});
  }
});
