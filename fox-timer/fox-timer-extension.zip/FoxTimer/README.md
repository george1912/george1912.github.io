ATI Assistant Timer — Install & Use Guide
=========================================

Also known as **Fox Timer** (fox icon in Chrome).

Recommended browser: Google Chrome


WHAT IT IS
----------
ATI Assistant Timer is a Chrome extension that helps keep ATI pages
from timing out while you study.


WHICH DOWNLOAD?
---------------
• Mac / most people: fox-timer-extension.zip
• Windows: fox-timer-windows.zip

Both open into a folder named FoxTimer (so Load unpacked is easy).


INSTALL ON WINDOWS
------------------
1. Download fox-timer-windows.zip
2. Right-click the ZIP → Extract All…
3. Choose a place you’ll keep (Documents is fine)
4. You should now have a folder named FoxTimer
5. Open Google Chrome
6. In the address bar type: chrome://extensions
7. Turn Developer mode ON (top-right)
8. Click Load unpacked
9. Select the FoxTimer folder (it contains manifest.json)

Do not delete the FoxTimer folder after installing.


INSTALL ON MAC
--------------
1. Download fox-timer-extension.zip
2. Double-click to unzip (you get a FoxTimer folder)
3. Move FoxTimer somewhere permanent (Documents is fine)
4. Open Google Chrome → chrome://extensions
5. Turn Developer mode ON
6. Click Load unpacked
7. Select the FoxTimer folder


HOW TO USE
----------
1. Open your ATI page in Chrome.
2. Click the fox icon (ATI Assistant Timer).
3. Choose what you are working on.
4. Enter how many minutes you want.
5. Press Play.

Keep the ATI window focused while it runs.


PROFILES
--------
ATI Lesson     Keeps the session awake and can move pages forward
Video Case     Keeps the session awake; closes when time is up
Assessment     You answer; when time is up it finishes for you
Popup Case     For Real Life popups (Beta) — check the window at the end


IF SOMETHING GOES WRONG
-----------------------
You can remove it anytime:

1. Go to chrome://extensions
2. Find ATI Assistant Timer
3. Click Remove

No account. No subscription. It just uninstalls.


TIPS
----
• Use Google Chrome for the best experience
• Try a short timer first (2–5 minutes)
• Advanced options can be ignored
• Open Study Buddy for a persistent tip carousel while you study

Version 1.5.0

While the timer runs, ATI Assistant Timer shows a study tip. Open Study Buddy for a
persistent tip carousel (study methods, time & breaks, fuel, check learning)
you can filter and regenerate anytime.
