const contentProfileEl = document.getElementById("contentProfile");
const durationMinutesEl = document.getElementById("durationMinutes");
const keepAliveOnlyEl = document.getElementById("keepAliveOnly");
const keepAliveIntervalSecondsEl = document.getElementById("keepAliveIntervalSeconds");
const closeLmsOnTimerEndEl = document.getElementById("closeLmsOnTimerEnd");
const holdAtSecondLastEl = document.getElementById("holdAtSecondLast");
const autoplayMediaEl = document.getElementById("autoplayMedia");
const autoFinishAfterTimerEl = document.getElementById("autoFinishAfterTimer");
const fallbackPageSecondsEl = document.getElementById("fallbackPageSeconds");

const formEl = document.getElementById("settingsForm");
const saveBtn = document.getElementById("saveBtn");
const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const stopBtn = document.getElementById("stopBtn");
const showLogBtn = document.getElementById("showLogBtn");
const copyLogBtn = document.getElementById("copyLogBtn");
const clearLogBtn = document.getElementById("clearLogBtn");
const statusEl = document.getElementById("status");
const statsEl = document.getElementById("stats");
const logOutputEl = document.getElementById("logOutput");
const modeBannerEl = document.getElementById("modeBanner");
const headerTimeEl = document.getElementById("headerTime");
const studyTipEl = document.getElementById("studyTip");
const studyTipBodyEl = document.getElementById("studyTipBody");
const studyTipNextBtn = document.getElementById("studyTipNextBtn");
const openBoardBtn = document.getElementById("openBoardBtn");
const openBoardAlwaysBtn = document.getElementById("openBoardAlwaysBtn");

let pollTimer = null;
let tipRotateTimer = null;
let lastTipIndex = -1;
let tipVisible = false;

const STUDY_TIPS = globalThis.FoxStudyTips?.plainTipBodies("all") || [
  "Explain one concept out loud like you’re teaching a classmate — if you stumble, that’s your next note.",
  "Write one “why it matters clinically” line under every key fact you capture.",
  "Quiz yourself: cover your notes and answer from memory for 60 seconds."
];

function setStatus(msg, isError = false) {
  if (!statusEl) return;
  statusEl.textContent = msg || "";
  statusEl.style.color = isError ? "#b42318" : "#5b6b7c";
}

function setBusy(busy) {
  [saveBtn, startBtn, pauseBtn, stopBtn].forEach((btn) => {
    if (btn) btn.disabled = !!busy;
  });
}

function clamp(n, min, max, fallback) {
  const v = Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.max(min, Math.min(max, Math.round(v)));
}

const PROFILE_LABELS = {
  atiLesson: "ATI Lesson",
  videoCase: "Video Case",
  assessment: "Assessment",
  popupCase: "Popup Case (Beta)"
};

const KEEP_ALIVE_PROFILES = new Set(["videoCase", "assessment", "popupCase"]);

function normalizeProfile(value) {
  const profile = String(value || "atiLesson");
  if (profile === "videoCase" || profile === "assessment" || profile === "popupCase") return profile;
  return "atiLesson";
}

function isKeepAliveProfile(profile) {
  return KEEP_ALIVE_PROFILES.has(normalizeProfile(profile));
}

function readSettingsFromForm() {
  return {
    contentProfile: normalizeProfile(contentProfileEl?.value),
    durationMinutes: clamp(durationMinutesEl?.value, 1, 1440, 30),
    keepAliveOnly: !!keepAliveOnlyEl?.checked,
    keepAliveIntervalSeconds: clamp(keepAliveIntervalSecondsEl?.value, 15, 300, 45),
    closeLmsOnTimerEnd: !!closeLmsOnTimerEndEl?.checked,
    holdAtSecondLast: !!holdAtSecondLastEl?.checked,
    autoplayMedia: !!autoplayMediaEl?.checked,
    autoFinishAfterTimer: !!autoFinishAfterTimerEl?.checked,
    fallbackPageSeconds: clamp(fallbackPageSecondsEl?.value, 2, 120, 5)
  };
}

function applySettingsToForm(settings) {
  if (!settings) return;
  if (contentProfileEl) {
    contentProfileEl.value = normalizeProfile(settings.contentProfile);
  }
  if (durationMinutesEl) durationMinutesEl.value = String(settings.durationMinutes ?? 30);
  if (keepAliveOnlyEl) keepAliveOnlyEl.checked = !!settings.keepAliveOnly;
  if (keepAliveIntervalSecondsEl) {
    keepAliveIntervalSecondsEl.value = String(settings.keepAliveIntervalSeconds ?? 45);
  }
  if (closeLmsOnTimerEndEl) closeLmsOnTimerEndEl.checked = !!settings.closeLmsOnTimerEnd;
  if (holdAtSecondLastEl) holdAtSecondLastEl.checked = !!settings.holdAtSecondLast;
  if (autoplayMediaEl) autoplayMediaEl.checked = !!settings.autoplayMedia;
  if (autoFinishAfterTimerEl) autoFinishAfterTimerEl.checked = !!settings.autoFinishAfterTimer;
  if (fallbackPageSecondsEl) fallbackPageSecondsEl.value = String(settings.fallbackPageSeconds ?? 5);
  updateAdvancedControls();
  renderModeBanner();
}

function currentProfile() {
  return normalizeProfile(contentProfileEl?.value);
}

function renderModeBanner() {
  if (!modeBannerEl) return;
  const profile = currentProfile();
  const assessmentHintEl = document.getElementById("assessmentHint");
  if (assessmentHintEl) {
    assessmentHintEl.style.display = profile === "assessment" ? "" : "none";
  }
  const popupCaseHintEl = document.getElementById("popupCaseHint");
  if (popupCaseHintEl) {
    popupCaseHintEl.style.display = profile === "popupCase" ? "" : "none";
  }
  const popupCaseBetaNoteEl = document.getElementById("popupCaseBetaNote");
  if (popupCaseBetaNoteEl) {
    popupCaseBetaNoteEl.style.display = profile === "popupCase" ? "" : "none";
  }
  if (profile === "videoCase") {
    modeBannerEl.textContent = "Keeps your session awake, then closes the Video Case when time is up.";
    return;
  }
  if (profile === "assessment") {
    modeBannerEl.textContent =
      "You answer the questions. The timer only holds extra time, then Continues and finalizes.";
    return;
  }
  if (profile === "popupCase") {
    modeBannerEl.textContent =
      "Keeps the Real Life / SCORM popup awake, then tries to click CLOSE when time is up.";
    return;
  }
  modeBannerEl.textContent = "Keeps the lesson moving and your session alive.";
}

function send(type, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, ...payload }, (resp) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      resolve(resp || null);
    });
  });
}

async function loadSettings() {
  const resp = await send("LHT_GET_SETTINGS");
  if (!resp?.ok) throw new Error(resp?.error || "Could not load settings");
  applySettingsToForm(resp.settings);
}

async function saveSettings() {
  const settings = readSettingsFromForm();
  const resp = await send("LHT_SAVE_SETTINGS", { settings });
  if (!resp?.ok) throw new Error(resp?.error || "Could not save settings");
  applySettingsToForm(resp.settings);
  return resp;
}

function formatMs(ms) {
  const totalSec = Math.max(0, Math.ceil(Number(ms || 0) / 1000));
  const mins = Math.floor(totalSec / 60);
  const sec = totalSec % 60;
  return `${mins}:${String(sec).padStart(2, "0")}`;
}

function pickStudyTip(forceNew = false) {
  if (!STUDY_TIPS.length) return "";
  if (!forceNew && lastTipIndex >= 0) {
    return STUDY_TIPS[lastTipIndex];
  }
  let next = lastTipIndex;
  do {
    next = Math.floor(Math.random() * STUDY_TIPS.length);
  } while (STUDY_TIPS.length > 1 && next === lastTipIndex);
  lastTipIndex = next;
  return STUDY_TIPS[next];
}

function showStudyTip(forceNew = false) {
  if (!studyTipEl || !studyTipBodyEl) return;
  const tip = pickStudyTip(forceNew || !tipVisible);
  studyTipBodyEl.textContent = tip;
  studyTipEl.classList.add("is-visible");
  tipVisible = true;
}

function hideStudyTip() {
  if (!studyTipEl) return;
  studyTipEl.classList.remove("is-visible");
  tipVisible = false;
  if (tipRotateTimer) {
    clearInterval(tipRotateTimer);
    tipRotateTimer = null;
  }
}

function ensureTipRotation() {
  if (tipRotateTimer) return;
  tipRotateTimer = setInterval(() => {
    if (tipVisible) showStudyTip(true);
  }, 120000);
}

function renderStatus(status) {
  if (!statsEl) return;
  if (!status?.running) {
    statsEl.textContent = "Ready — choose a profile and press Play.";
    if (headerTimeEl) headerTimeEl.textContent = "--:--";
    if (startBtn) startBtn.disabled = false;
    if (pauseBtn) pauseBtn.disabled = true;
    if (pauseBtn) pauseBtn.textContent = "Pause";
    if (stopBtn) stopBtn.disabled = false;
    hideStudyTip();
    return;
  }

  showStudyTip(false);
  ensureTipRotation();

  if (startBtn) startBtn.disabled = !status?.paused;
  if (pauseBtn) pauseBtn.disabled = false;
  if (pauseBtn) pauseBtn.textContent = status?.paused ? "Resume" : "Pause";
  if (stopBtn) stopBtn.disabled = false;

  const remaining = formatMs(status.remainingMs);
  if (headerTimeEl) headerTimeEl.textContent = remaining;

  const profile = normalizeProfile(status?.settings?.contentProfile);
  const profileLabel = PROFILE_LABELS[profile] || "ATI Lesson";
  const lines = [];
  lines.push(status?.paused ? "Paused" : "Running");
  lines.push(`${remaining} left`);
  lines.push(profileLabel);

  const toc = status?.lastReport?.toc;
  if (toc?.known) {
    lines.push(`Step ${Math.max(0, toc.currentIndex + 1)}/${toc.total}`);
  }

  if (Number(status.remainingMs) <= 0) {
    lines.push("Finishing…");
  }

  statsEl.textContent = lines.join(" · ");
}

function updateAdvancedControls() {
  const profile = currentProfile();
  const keepAliveOnly = !!keepAliveOnlyEl?.checked || isKeepAliveProfile(profile);
  const advancedIds = [
    "holdAtSecondLastWrap",
    "autoplayMediaWrap",
    "autoFinishAfterTimerWrap",
    "fallbackPageSecondsWrapLabel"
  ];
  for (const id of advancedIds) {
    const el = document.getElementById(id);
    if (el) el.style.display = keepAliveOnly ? "none" : "";
  }
  if (keepAliveOnlyEl) keepAliveOnlyEl.disabled = isKeepAliveProfile(profile);
  if (isKeepAliveProfile(profile) && keepAliveOnlyEl) keepAliveOnlyEl.checked = true;

  const closeLabel = closeLmsOnTimerEndEl?.closest("label");
  if (closeLabel) {
    const textNode = Array.from(closeLabel.childNodes).find(
      (n) => n.nodeType === Node.TEXT_NODE && String(n.textContent || "").trim()
    );
    if (textNode) {
      textNode.textContent =
        profile === "assessment"
          ? " When timer ends, Continue → Finalize and View Results"
          : profile === "popupCase"
            ? " When timer ends, click CLOSE on the SCORM popup"
            : profile === "videoCase"
              ? " When timer ends, close Video Case automatically"
              : " When timer ends, click LMS Close automatically";
    }
  }
}

async function refreshStatus() {
  try {
    const resp = await send("LHT_GET_STATUS");
    if (resp?.ok) {
      renderStatus(resp.status);
      if (resp.status?.running) {
        if (resp.status?.paused) {
          setStatus(`Paused - ${formatMs(resp.status.remainingMs)} left`);
        } else {
          setStatus(`Running - ${formatMs(resp.status.remainingMs)} left`);
        }
      } else if (resp.status?.settings?.keepAliveOnly) {
        setStatus("");
      }
    }
  } catch {
    // Ignore transient popup messaging failures.
  }
}

async function onSave(e) {
  e.preventDefault();
  try {
    setBusy(true);
    const resp = await saveSettings();
    if (resp?.stoppedForDurationChange) {
      setStatus("Timer stopped because the time changed. Press Play to start again with the new duration.");
    } else {
      setStatus("Settings saved.");
    }
    await refreshStatus();
  } catch (err) {
    setStatus(err?.message || String(err), true);
  } finally {
    setBusy(false);
  }
}

async function stopForTimeEdit(reason) {
  try {
    const statusResp = await send("LHT_GET_STATUS");
    if (!statusResp?.status?.running) return false;
    await send("LHT_STOP");
    setStatus(reason);
    await refreshStatus();
    return true;
  } catch {
    return false;
  }
}

async function onStart() {
  try {
    setBusy(true);
    const profile = currentProfile();
    setStatus(`Starting ${PROFILE_LABELS[profile] || "ATI Lesson"} mode...`);
    const saveResp = await saveSettings();
    const settings = saveResp?.settings || readSettingsFromForm();
    // ATI lesson: autoplay. Video Case / Assessment: keep-alive timer only.
    const playSettings = isKeepAliveProfile(settings.contentProfile)
      ? {
        ...settings,
        keepAliveOnly: true,
        autoplayMedia: false,
        holdAtSecondLast: false,
        autoFinishAfterTimer: false,
        closeLmsOnTimerEnd: true
      }
      : { ...settings, keepAliveOnly: false, closeLmsOnTimerEnd: true };
    const resp = await send("LHT_START", { settings: playSettings, restart: true });
    if (!resp?.ok) throw new Error(resp?.error || "Could not start");
    setStatus(`Playing - ${formatMs(resp.status?.remainingMs)} left`);
    renderStatus(resp.status);
  } catch (err) {
    setStatus(err?.message || String(err), true);
  } finally {
    setBusy(false);
  }
}

async function onStop() {
  try {
    setBusy(true);
    const resp = await send("LHT_STOP");
    if (!resp?.ok) throw new Error(resp?.error || "Could not stop");
    setStatus("Autoplay ended.");
    renderStatus(resp.status);
  } catch (err) {
    setStatus(err?.message || String(err), true);
  } finally {
    setBusy(false);
  }
}

async function onPause() {
  try {
    setBusy(true);
    const resp = await send("LHT_TOGGLE_PAUSE");
    if (!resp?.ok) throw new Error(resp?.error || "Could not toggle pause");
    if (resp.status?.paused) {
      setStatus(`Paused - ${formatMs(resp.status?.remainingMs)} left`);
    } else {
      setStatus(`Playing - ${formatMs(resp.status?.remainingMs)} left`);
    }
    renderStatus(resp.status);
  } catch (err) {
    setStatus(err?.message || String(err), true);
  } finally {
    setBusy(false);
  }
}

function formatLogEntry(entry) {
  if (entry?.event) {
    const at = new Date(entry?.at || Date.now()).toLocaleTimeString();
    return `[${at}] event=${entry.event}${entry.level ? ` level=${entry.level}` : ""}`;
  }

  const at = new Date(entry?.at || Date.now()).toLocaleTimeString();
  const stage = entry?.report?.stage || "unknown";
  const rem = Number(entry?.report?.remainingMs);
  const remText = Number.isFinite(rem) ? formatMs(rem) : "n/a";
  const moved = entry?.report?.moved;
  const moveType = entry?.report?.moveType || "none";
  const moveDelta = entry?.report?.moveDelta;
  const moveText = moved ? `${moveType}:${moveDelta}` : "none";
  const safeClicked = entry?.report?.safeClicked ? "yes" : "no";
  const safeReason = entry?.report?.safeClickReason || "";
  const closeStage =
    stage === "timer-end-close-clicked" ||
    stage === "timer-end-close-not-found" ||
    stage === "timer-end-close-failed";
  const closeTarget =
    entry?.report?.closeTargetTag && entry?.report?.closeTargetClass
      ? `${entry.report.closeTargetTag}.${entry.report.closeTargetClass}`
      : "";
  const url = entry?.url || "";
  return `[${at}] stage=${stage}${closeStage && closeTarget ? ` closeTarget=${closeTarget}` : ""} move=${moveText} safeClick=${safeClicked}${safeReason ? `(${safeReason})` : ""} remaining=${remText} frame=${entry?.frameId} ${url}`;
}

async function onShowLog() {
  try {
    const resp = await send("LHT_GET_DEBUG_LOG");
    if (!resp?.ok) throw new Error(resp?.error || "Could not read debug log");
    const log = Array.isArray(resp.log) ? resp.log : [];
    if (!logOutputEl) return;
    if (!log.length) {
      logOutputEl.value = "No debug entries yet.";
      return;
    }
    logOutputEl.value = log.map(formatLogEntry).join("\n");
  } catch (err) {
    setStatus(err?.message || String(err), true);
  }
}

async function onCopyLog() {
  if (!logOutputEl) return;
  try {
    await navigator.clipboard.writeText(logOutputEl.value || "");
    setStatus("Debug log copied.");
  } catch {
    setStatus("Could not copy log. Select and copy manually.", true);
  }
}

async function onClearLog() {
  try {
    const resp = await send("LHT_CLEAR_DEBUG_LOG");
    if (!resp?.ok) throw new Error(resp?.error || "Could not clear debug log");
    if (logOutputEl) logOutputEl.value = "";
    setStatus("Debug log cleared.");
  } catch (err) {
    setStatus(err?.message || String(err), true);
  }
}

formEl?.addEventListener("submit", onSave);
startBtn?.addEventListener("click", onStart);
pauseBtn?.addEventListener("click", onPause);
stopBtn?.addEventListener("click", onStop);
keepAliveOnlyEl?.addEventListener("change", updateAdvancedControls);
contentProfileEl?.addEventListener("change", updateAdvancedControls);
contentProfileEl?.addEventListener("change", renderModeBanner);
durationMinutesEl?.addEventListener("change", () => {
  stopForTimeEdit("Timer stopped because the time changed. Press Play when you want the new duration.");
});
showLogBtn?.addEventListener("click", onShowLog);
copyLogBtn?.addEventListener("click", onCopyLog);
clearLogBtn?.addEventListener("click", onClearLog);
studyTipNextBtn?.addEventListener("click", () => showStudyTip(true));

async function openStudyBoard() {
  try {
    const resp = await send("LHT_OPEN_COMPANION");
    if (!resp?.ok) throw new Error(resp?.error || "Could not open Study Board");
    setStatus("Study Board opened.");
  } catch (err) {
    setStatus(err?.message || String(err), true);
  }
}

openBoardBtn?.addEventListener("click", openStudyBoard);
openBoardAlwaysBtn?.addEventListener("click", openStudyBoard);

(async () => {
  try {
    await loadSettings();
    await refreshStatus();
    pollTimer = setInterval(refreshStatus, 1000);
  } catch (err) {
    setStatus(err?.message || String(err), true);
  }
})();

window.addEventListener("beforeunload", () => {
  if (pollTimer) clearInterval(pollTimer);
});
