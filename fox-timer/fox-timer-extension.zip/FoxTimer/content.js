// ITA Lecture Assist Timer - content script

const IS_TOP = window.top === window;

console.info("[LHT] script loaded", { href: location.href, isTop: IS_TOP });

const STATE = {
  running: false,
  startedAt: 0,
  endAt: 0,
  settings: {
    contentProfile: "atiLesson",
    durationMinutes: 30,
    keepAliveOnly: false,
    keepAliveIntervalSeconds: 45,
    closeLmsOnTimerEnd: false,
    holdAtSecondLast: true,
    autoplayMedia: true,
    fallbackPageSeconds: 5,
    autoFinishAfterTimer: true
  },
  loopToken: 0,
  lastContinueAt: 0,
  lastSignature: "",
  gateToastShown: false,
  mediaStartBySig: Object.create(null),
  playPressBySig: Object.create(null),
  keepAliveTouchedAt: 0,
  countdownTickId: null,
  lastSafeClickAt: 0,
  lmsTokenExpMs: 0,
  lmsPreExpiryHandled: false,
  modalWatchdogId: null,
  lastSessionWarningDismissAt: 0
};

function nowMs() {
  return Date.now();
}

function isLmsHost() {
  return /(^|\.)lms\.atitesting\.com$/i.test(location.hostname);
}

function isAtiHost() {
  return /(^|\.)(student|assessments|lms|vcs|scorm)\.atitesting\.com$/i.test(location.hostname);
}

function isScormHost() {
  return /(^|\.)scorm\.atitesting\.com$/i.test(location.hostname);
}

function isVideoCaseProfile() {
  return String(STATE.settings?.contentProfile || "") === "videoCase";
}

function isAssessmentProfile() {
  return String(STATE.settings?.contentProfile || "") === "assessment";
}

function isPopupCaseProfile() {
  return String(STATE.settings?.contentProfile || "") === "popupCase";
}

function isKeepAliveProfile() {
  return (
    isVideoCaseProfile() ||
    isAssessmentProfile() ||
    isPopupCaseProfile() ||
    !!STATE.settings?.keepAliveOnly
  );
}

function shouldControlFrame() {
  // ATI lesson content can render in top page, LMS iframe, or tutorial subframes.
  if (IS_TOP) return true;
  if (isLmsHost()) return true;
  // Quiz content always lives in assessments.* iframes for Assessment profile.
  if (/(^|\.)assessments\.atitesting\.com$/i.test(location.hostname)) return true;
  // Real Life / SCORM popup content (launchpage + contentFrame pages).
  if (isScormHost()) return true;
  if (!isAtiHost()) return false;
  try {
    const fe = window.frameElement;
    const frameMeta = textNorm(
      `${fe?.id || ""} ${fe?.name || ""} ${fe?.className || ""} ${fe?.getAttribute?.("title") || ""}`
    );
    if (/(tutorial|lesson|content|module|player|slide|assessment)/.test(frameMeta)) return true;
  } catch {
    // ignore frame metadata access failures
  }
  // Fallback: if this frame visibly exposes lesson controls, allow control.
  return frameHasAutomationTargets();
}

function remainingMs() {
  return Math.max(0, Number(STATE.endAt || 0) - nowMs());
}

function timerReached() {
  return remainingMs() <= 0;
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function collectSearchDocuments(rootWin, out, depth = 0) {
  if (!rootWin || depth > 4) return;
  try {
    if (rootWin.document && !out.includes(rootWin.document)) out.push(rootWin.document);
  } catch {
    return;
  }

  let frames = [];
  try {
    frames = [...rootWin.document.querySelectorAll("iframe, frame")];
  } catch {
    frames = [];
  }

  for (const fr of frames) {
    try {
      const cw = fr.contentWindow;
      if (!cw) continue;
      collectSearchDocuments(cw, out, depth + 1);
    } catch {
      // Cross-origin frame, ignore.
    }
  }
}

function getSearchDocuments() {
  if (!IS_TOP) return [document];
  const out = [];
  collectSearchDocuments(window, out, 0);
  return out.length ? out : [document];
}

function textNorm(s) {
  return String(s || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function isVisible(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
  const hasBox = !!rect && rect.width > 1 && rect.height > 1;
  if (el.offsetParent === null && el.tagName !== "VIDEO" && !hasBox) return false;
  const style = getComputedStyle(el);
  if (style.visibility === "hidden" || style.display === "none") return false;
  if (style.pointerEvents === "none") return false;
  return true;
}

function formatDuration(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const mins = Math.floor(total / 60);
  const secs = total % 60;
  return `${mins}:${String(secs).padStart(2, "0")}`;
}

function decodeBase64Url(raw) {
  try {
    let s = String(raw || "").replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4) s += "=";
    return atob(s);
  } catch {
    return "";
  }
}

function getLmsTokenInfoFromLocation() {
  try {
    const match = location.href.match(/lms\.atitesting\.com\/([^/?#]+)/i);
    if (!match || !match[1]) return null;
    const token = match[1];
    const parts = token.split(".");
    if (parts.length < 2) return null;
    const payloadRaw = decodeBase64Url(parts[1]);
    if (!payloadRaw) return null;
    const payload = JSON.parse(payloadRaw);
    const expSec = Number(payload?.exp);
    if (!Number.isFinite(expSec) || expSec <= 0) return null;
    return {
      expMs: expSec * 1000
    };
  } catch {
    return null;
  }
}

function toast(message, level = "info", timeoutMs = 2200) {
  if (!IS_TOP) return;
  const old = document.getElementById("lht-toast");
  if (old) old.remove();

  const box = document.createElement("div");
  box.id = "lht-toast";
  box.className = `lht-toast lht-${level}`;
  box.textContent = message;
  document.documentElement.appendChild(box);
  setTimeout(() => {
    try {
      box.remove();
    } catch {
      // ignore
    }
  }, timeoutMs);
}

function getCountdownBadge() {
  const id = "lht-countdown-badge";
  let badge = document.getElementById(id);
  if (!badge) {
    badge = document.createElement("div");
    badge.id = id;
    badge.setAttribute("aria-live", "polite");
    badge.style.position = "fixed";
    badge.style.top = "12px";
    badge.style.right = "12px";
    badge.style.zIndex = "2147483647";
    badge.style.background = "rgba(15, 23, 42, 0.92)";
    badge.style.color = "#f8fafc";
    badge.style.padding = "8px 10px";
    badge.style.borderRadius = "8px";
    badge.style.font = '12px/1.3 "Avenir Next", "Segoe UI", sans-serif';
    badge.style.boxShadow = "0 8px 18px rgba(2, 6, 23, 0.35)";
    badge.style.border = "1px solid rgba(255,255,255,0.12)";
    badge.style.pointerEvents = "none";
    document.documentElement.appendChild(badge);
  }
  return badge;
}

function stopCountdownBadge() {
  if (STATE.countdownTickId) {
    clearInterval(STATE.countdownTickId);
    STATE.countdownTickId = null;
  }
  const badge = document.getElementById("lht-countdown-badge");
  if (badge) {
    try {
      badge.remove();
    } catch {
      // ignore removal errors
    }
  }
}

function stopModalWatchdog() {
  if (STATE.modalWatchdogId) {
    clearInterval(STATE.modalWatchdogId);
    STATE.modalWatchdogId = null;
  }
}

function renderCountdownBadge() {
  if (!STATE.running) {
    stopCountdownBadge();
    return;
  }
  const badge = getCountdownBadge();
  const rem = formatDuration(remainingMs());
  let mode = "Autoplay";
  if (isAssessmentProfile()) mode = "Assessment";
  else if (isPopupCaseProfile()) mode = "Popup Case";
  else if (isVideoCaseProfile()) mode = "Video Case";
  else if (STATE.settings.keepAliveOnly) mode = "Keep-alive";
  badge.textContent = `${mode}: ${rem} left`;
}

function startCountdownBadge() {
  renderCountdownBadge();
  if (STATE.countdownTickId) clearInterval(STATE.countdownTickId);
  STATE.countdownTickId = setInterval(renderCountdownBadge, 1000);
}

function startModalWatchdog() {
  stopModalWatchdog();
  STATE.modalWatchdogId = setInterval(() => {
    if (!STATE.running) return;
    dismissSessionWarningIfPresent();
  }, 1200);
}

function deriveRunningFromPayload(payload) {
  if (payload && typeof payload === "object" && payload.status && typeof payload.status === "object") {
    return payload.status;
  }
  return payload || null;
}

function frameHasAutomationTargets() {
  const hasPlay = !!findPrimaryPlayButton() || !!findPlayButtonNear(null);
  const hasDuration = Number.isFinite(findMediaDurationSeconds());
  const hasContinue = !!findContinueButton();
  const hasActiveTitle = !!getActiveSectionTitle();
  return hasPlay || hasDuration || hasContinue || hasActiveTitle;
}

function parseClockToSeconds(raw) {
  const s = String(raw || "").trim();
  if (!s) return NaN;
  const parts = s.split(":").map((x) => Number(x));
  if (parts.some((n) => !Number.isFinite(n))) return NaN;
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  return NaN;
}

function getActiveSectionTitle() {
  for (const doc of getSearchDocuments()) {
    const el = doc.querySelector("#activeFocusTutorialItemTitle");
    if (!el || !isVisible(el)) continue;
    return String(el.textContent || "").replace(/\s+/g, " ").trim();
  }
  return "";
}

function getOrderedSectionTitles() {
  const bucket = [];
  const selectors = [
    "#activeFocusTutorialItemTitle",
    "[data-bind*='Name'][title]",
    "li [title]",
    "a[title]",
    "span[title]"
  ];

  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      const nodes = doc.querySelectorAll(sel);
      for (const node of nodes) {
        if (!isVisible(node)) continue;
        const txt = String(node.getAttribute("title") || node.textContent || "")
          .replace(/\s+/g, " ")
          .trim();
        if (!txt || txt.length < 2) continue;
        if (/table of contents|expand all|menu|tools|close/i.test(txt)) continue;
        bucket.push(txt);
      }
    }
  }

  const out = [];
  const seen = new Set();
  for (const t of bucket) {
    const k = textNorm(t);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    out.push(t);
  }
  return out;
}

function getTocContainer() {
  const candidates = [
    ".table-of-contents",
    "#table-of-contents",
    "[data-testid*='table-of-contents']",
    "[data-testid*='toc']",
    ".toc",
    "nav"
  ];

  for (const doc of getSearchDocuments()) {
    for (const sel of candidates) {
      const nodes = doc.querySelectorAll(sel);
      for (const node of nodes) {
        const t = textNorm(node.textContent);
        if (/table of contents|introduction|summary|case study/.test(t)) return node;
      }
    }

    const all = doc.querySelectorAll("div, nav, aside");
    for (const node of all) {
      const t = textNorm(node.textContent);
      if (t.includes("table of contents")) return node;
    }
  }
  return null;
}

function getTocItems() {
  const container = getTocContainer();
  if (!container) return [];

  const nodes = [
    ...container.querySelectorAll("li, a, button, .menu-item, .toc-item, .nav-item, div")
  ].filter((el) => {
    if (!isVisible(el)) return false;
    const txt = textNorm(el.textContent);
    if (!txt || txt.length < 3) return false;
    if (/table of contents|expand all|menu|tools/.test(txt)) return false;
    return true;
  });

  const dedup = [];
  const seen = new Set();
  for (const n of nodes) {
    const key = textNorm(n.textContent).slice(0, 120);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    dedup.push(n);
  }
  return dedup;
}

function getCurrentTocIndex(items) {
  const activeTitle = textNorm(getActiveSectionTitle());
  if (activeTitle) {
    for (let i = 0; i < items.length; i++) {
      if (textNorm(items[i].textContent || items[i].title || "") === activeTitle) return i;
    }
  }

  if (!items.length) return -1;

  for (let i = 0; i < items.length; i++) {
    const el = items[i];
    const cls = textNorm(el.className);
    const aria = textNorm(el.getAttribute("aria-current") || "");
    if (/active|current|selected|open/.test(cls)) return i;
    if (aria === "true" || aria === "page" || aria === "step") return i;
  }

  for (let i = 0; i < items.length; i++) {
    const t = textNorm(items[i].textContent);
    if (/\bintroduction\b/.test(t) && /\bmodule\b/.test(textNorm(document.title))) return i;
  }

  return -1;
}

function isAtSecondLast() {
  const orderedTitles = getOrderedSectionTitles();
  const activeTitle = textNorm(getActiveSectionTitle());

  if (orderedTitles.length >= 2 && activeTitle) {
    const currentIndex = orderedTitles.findIndex((t) => textNorm(t) === activeTitle);
    if (currentIndex >= 0) {
      const total = orderedTitles.length;
      return {
        atSecondLast: currentIndex >= total - 2,
        known: true,
        currentIndex,
        total,
        activeTitle
      };
    }
  }

  const items = getTocItems();
  const total = items.length;
  const currentIndex = getCurrentTocIndex(items);
  if (total < 2 || currentIndex < 0) {
    return { atSecondLast: false, known: false, currentIndex, total, activeTitle };
  }
  return {
    atSecondLast: currentIndex >= total - 2,
    known: true,
    currentIndex,
    total,
    activeTitle
  };
}

function pageSignature() {
  const active = textNorm(getActiveSectionTitle());
  const heading = document.querySelector("h1, h2, [role='heading']");
  const headingText = textNorm(heading?.textContent || "").slice(0, 80);
  const ctr = isAtSecondLast();
  return `${location.pathname}|${active || headingText}|${ctr.currentIndex}/${ctr.total}`;
}

function findPlayableVideo() {
  const videos = [];
  for (const doc of getSearchDocuments()) {
    const local = [...doc.querySelectorAll("video")].filter((v) => {
      if (!isVisible(v)) return false;
      const rect = v.getBoundingClientRect();
      return rect.width > 80 && rect.height > 80;
    });
    videos.push(...local);
  }

  if (!videos.length) return null;

  videos.sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    return rb.width * rb.height - ra.width * ra.height;
  });

  return videos[0];
}

function findPlayButtonNear(videoEl) {
  const selectors = [
    "input.media-play-button[aria-label*='play' i]",
    "input.media-play-button",
    "button[aria-label*='play' i]",
    "button[title*='play' i]",
    ".vjs-play-control",
    ".mejs__playpause-button",
    "button"
  ];

  const docs = videoEl?.ownerDocument ? [videoEl.ownerDocument] : getSearchDocuments();
  for (const doc of docs) {
    for (const sel of selectors) {
      const nodes = doc.querySelectorAll(sel);
      for (const n of nodes) {
        if (!isVisible(n)) continue;
        const txt = textNorm(n.textContent + " " + (n.getAttribute("aria-label") || ""));
        const near = videoEl ? n.closest(".video, .player, .media, .content, .module") : null;
        if (/play/.test(txt) || (near && near.contains(videoEl))) return n;
      }
    }
  }

  return null;
}

function findPrimaryPlayButton() {
  for (const doc of getSearchDocuments()) {
    const direct = doc.querySelector("input.media-play-button[aria-label*='play or pause' i]")
      || doc.querySelector("input.media-play-button[aria-label*='play' i]")
      || doc.querySelector("input.media-play-button")
      || doc.querySelector("button[aria-label*='play' i]")
      || doc.querySelector("button[title*='play' i]");
    if (direct && isVisible(direct)) return direct;
  }
  return null;
}

function playButtonIndicatesPaused(btn) {
  if (!btn) return false;
  const cls = textNorm(btn.className || "");
  if (/fa-pause/.test(cls)) return false;
  if (/fa-play/.test(cls)) return true;

  // Fallback for non-ATI players that expose play/pause in class names.
  if (/\bpaused\b/.test(cls)) return true;
  if (/\bplaying\b/.test(cls)) return false;
  return false;
}

function ensurePlayPressedForSig(sig) {
  if (!STATE.running) return false;
  const btn = findPrimaryPlayButton() || findPlayButtonNear(null);
  if (!btn) return false;

  const now = nowMs();
  const last = Number(STATE.playPressBySig[sig]) || 0;
  const retryWindowMs = 15000;
  const needsPress = !last || playButtonIndicatesPaused(btn) || (now - last) > retryWindowMs;
  const cooldownOk = (now - last) > 4000;
  if (!needsPress || !cooldownOk) return false;

  const ok = forceActivateElement(btn);
  if (!ok) return false;
  STATE.playPressBySig[sig] = now;
  return true;
}

function findMediaDurationSeconds() {
  for (const doc of getSearchDocuments()) {
    const lbl = doc.querySelector(".media-maximum-time-label");
    if (!lbl || !isVisible(lbl)) continue;
    const secs = parseClockToSeconds(lbl.textContent || "");
    if (Number.isFinite(secs)) return secs;
  }
  return NaN;
}

function mediaElapsedMsForSig(sig) {
  const startedAt = STATE.mediaStartBySig[sig];
  if (!Number.isFinite(startedAt)) return 0;
  return Math.max(0, nowMs() - startedAt);
}

function markMediaStartForSig(sig) {
  if (!sig) return;
  if (!Number.isFinite(STATE.mediaStartBySig[sig])) {
    STATE.mediaStartBySig[sig] = nowMs();
  }
}

async function waitByDurationLabel(sig, token) {
  const durSec = findMediaDurationSeconds();
  if (!Number.isFinite(durSec) || durSec <= 0) return false;

  const padMs = 2000;
  const targetMs = durSec * 1000 + padMs;
  markMediaStartForSig(sig);

  while (STATE.running && token === STATE.loopToken) {
    if (!frameHasAutomationTargets()) {
      await wait(900);
      continue;
    }

    const elapsed = mediaElapsedMsForSig(sig);
    if (elapsed >= targetMs) return true;

    if (STATE.settings.autoplayMedia) ensurePlayPressedForSig(sig);

    await reportProgress("media-label", {
      expectedMs: targetMs,
      elapsedMs: elapsed
    });
    await wait(1000);
  }

  return false;
}

function detectQuestionPrompt() {
  if (!isLmsHost()) return null;
  for (const doc of getSearchDocuments()) {
    const context = textNorm((doc.body?.textContent || "").slice(0, 3000));
    const looksLikeQuestionText = /case study|question|select all that apply|choose|answer|submit/.test(context);

    const choiceInputs = [...doc.querySelectorAll("input[type='radio'], input[type='checkbox']")]
      .filter((el) => isVisible(el) && !el.disabled);
    if (choiceInputs.length >= 2 && looksLikeQuestionText) {
      return { type: "choice-inputs", count: choiceInputs.length };
    }

    const textAnswer = [...doc.querySelectorAll("textarea, input[type='text']")]
      .filter((el) => isVisible(el) && !el.disabled);
    if (textAnswer.length >= 1) {
      if (/case study|question|select all that apply|choose|answer/.test(context)) {
        return { type: "text-question", count: textAnswer.length };
      }
    }
  }
  return null;
}

async function ensureVideoPlaying(video) {
  if (!video) return false;
  if (!STATE.settings.autoplayMedia) return false;

  try {
    if (video.ended) return false;
    if (!video.paused && !video.seeking && video.readyState >= 2) return true;

    const playButton = findPlayButtonNear(video);
    if (playButton) {
      forceActivateElement(playButton);
    }

    try {
      await video.play();
      return true;
    } catch {
      return !video.paused;
    }
  } catch {
    return false;
  }
}

async function waitForVideoDone(video, token) {
  let staleChecks = 0;
  while (STATE.running && token === STATE.loopToken) {
    if (!video || !document.contains(video) || !isVisible(video)) {
      staleChecks += 1;
      if (staleChecks >= 3) return false;
      await wait(500);
      continue;
    }

    if (video.ended) return true;

    if (video.paused && !video.ended) {
      await ensureVideoPlaying(video);
    }

    await reportProgress("video", { ended: !!video.ended, paused: !!video.paused });
    await wait(1000);
  }
  return false;
}

function findContinueButton() {
  const selectors = [
    "a.move-to-next-content-active[data-bind*='LoadNextPage']",
    "a.move-to-next-content-active[role='button']",
    "a.move-to-next-content-active",
    "a[aria-label*='navigate to next slide' i]",
    "button[aria-label*='navigate to next slide' i]",
    "[data-testid*='next' i]",
    "[data-test*='next' i]",
    "[class*='next' i]",
    "#moveNext",
    "button[aria-label*='continue' i]",
    "button[title*='continue' i]",
    "button[aria-label*='next' i]",
    "button:enabled",
    "a[role='button']"
  ];

  const candidates = [];
  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      const nodes = doc.querySelectorAll(sel);
      for (const n of nodes) {
        if (!isVisible(n)) continue;
        if (n.matches("[disabled], [aria-disabled='true']")) continue;
        const id = String(n.id || "").toLowerCase();
        const cls = String(n.className || "").toLowerCase();
        const txt = textNorm(
          (n.textContent || "") +
          " " + (n.getAttribute("aria-label") || "") +
          " " + (n.getAttribute("title") || "")
        );
        const byText = /continue|next|proceed|advance/.test(txt);
        const byId = id === "movenext" || id.includes("next") || id.includes("continue");
        const byClass =
          cls.includes("move-to-next-content-active") ||
          cls.includes("next") ||
          cls.includes("continue");
        if (!byText && !byId && !byClass) continue;
        if (txt && /end test|finish|quit|close|submit/.test(txt)) continue;
        {
          const rect = n.getBoundingClientRect();
          let score = 0;
          if (n.matches("a.move-to-next-content-active[data-bind*='LoadNextPage']")) score += 16;
          if (n.matches("a.move-to-next-content-active")) score += 10;
          if (byId) score += 8;
          if (byClass) score += 6;
          if (/loadnextpage/i.test(String(n.getAttribute("data-bind") || ""))) score += 8;
          if (/navigate to next slide/.test(txt)) score += 4;
          if (/continue/.test(txt)) score += 4;
          if (/next/.test(txt)) score += 3;
          if (rect.left > window.innerWidth * 0.5) score += 1;
          candidates.push({ el: n, score });
        }
      }
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates.length ? candidates[0].el : null;
}

async function clickContinue() {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const btn = findContinueButton();
    if (!btn) {
      await wait(220);
      continue;
    }
    let ok = forceActivateElement(btn);
    if (!ok && /loadnextpage/i.test(String(btn.getAttribute("data-bind") || ""))) {
      ok = invokeKnockoutClick(btn);
    }
    if (ok) {
      await reportProgress("continue-clicked", {
        continueTag: String(btn.tagName || "").toLowerCase(),
        continueClass: String(btn.className || "").slice(0, 100),
        continueAria: String(btn.getAttribute("aria-label") || "").slice(0, 100),
        continueAttempt: attempt + 1
      });
      STATE.lastContinueAt = nowMs();
      return true;
    }
    await wait(240);
  }
  return false;
}

function sanitizeHref(raw) {
  try {
    const u = new URL(String(raw || ""));
    const host = String(u.hostname || "").toLowerCase();
    if (!host.endsWith(".atitesting.com") && host !== "atitesting.com") return "";
    return `${u.origin}${u.pathname}`.slice(0, 180);
  } catch {
    return String(raw || "").split("?")[0].split("#")[0].slice(0, 180);
  }
}

async function reportProgress(stage, extra = {}) {
  try {
    const toc = isAtSecondLast();
    const safeExtra = { ...extra };
    if (Object.prototype.hasOwnProperty.call(safeExtra, "href")) {
      safeExtra.href = sanitizeHref(safeExtra.href);
    }
    if (Object.prototype.hasOwnProperty.call(safeExtra, "url")) {
      safeExtra.url = sanitizeHref(safeExtra.url);
    }
    chrome.runtime.sendMessage({
      type: "LHT_PAGE_REPORT",
      report: {
        stage,
        remainingMs: remainingMs(),
        signature: pageSignature(),
        toc,
        ...safeExtra
      }
    }, () => {});
  } catch {
    // ignore
  }
}

function notifyBackground(type, payload = {}) {
  try {
    chrome.runtime.sendMessage({ type, ...payload }, () => {});
  } catch {
    // ignore background notify failures
  }
}

function getKeepAliveMarker() {
  const id = "lht-keepalive-marker";
  let marker = document.getElementById(id);
  if (!marker) {
    marker = document.createElement("div");
    marker.id = id;
    marker.setAttribute("aria-hidden", "true");
    marker.style.position = "fixed";
    marker.style.right = "8px";
    marker.style.bottom = "8px";
    marker.style.width = "1px";
    marker.style.height = "1px";
    marker.style.opacity = "0";
    marker.style.pointerEvents = "none";
    marker.style.zIndex = "1";
    document.documentElement.appendChild(marker);
  }
  return marker;
}

function findScrollableContainer() {
  const candidates = [
    document.querySelector("main"),
    document.querySelector("[role='main']"),
    document.querySelector("article"),
    document.querySelector(".content"),
    document.querySelector(".module"),
    ...document.querySelectorAll("div, section")
  ].filter(Boolean);

  for (const el of candidates) {
    if (!isVisible(el)) continue;
    const overflowY = getComputedStyle(el).overflowY;
    const canScroll = el.scrollHeight - el.clientHeight > 6;
    if (!canScroll) continue;
    if (overflowY === "auto" || overflowY === "scroll") return el;
  }
  return null;
}

async function nudgeScrollAndRestore({ maxPixels = 16 } = {}) {
  const root = document.scrollingElement || document.documentElement || document.body;
  const startX = window.scrollX;
  const startY = window.scrollY;
  const totalHeight = Math.max(
    root?.scrollHeight || 0,
    document.documentElement?.scrollHeight || 0,
    document.body?.scrollHeight || 0
  );
  const maxY = Math.max(0, totalHeight - window.innerHeight);
  const result = { moved: false, moveType: "none", moveDelta: 0 };

  let delta = 0;
  if (maxY > 2) {
    const roomBelow = maxY - startY;
    const roomAbove = startY;
    if (roomBelow >= 2) {
      delta = Math.min(maxPixels, roomBelow);
    } else if (roomAbove >= 2) {
      delta = -Math.min(maxPixels, roomAbove);
    }

    if (delta !== 0) {
      window.scrollTo(startX, startY + delta);
      await wait(120);
      window.scrollTo(startX, startY);
      result.moved = true;
      result.moveType = "window-scroll";
      result.moveDelta = delta;
      return result;
    }
  }

  const scroller = findScrollableContainer();
  if (scroller) {
    const originalTop = scroller.scrollTop;
    const maxTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    let localDelta = 0;
    if (maxTop - originalTop >= 2) {
      localDelta = Math.min(maxPixels, maxTop - originalTop);
    } else if (originalTop >= 2) {
      localDelta = -Math.min(maxPixels, originalTop);
    }
    if (localDelta !== 0) {
      scroller.scrollTop = originalTop + localDelta;
      await wait(120);
      scroller.scrollTop = originalTop;
      result.moved = true;
      result.moveType = "container-scroll";
      result.moveDelta = localDelta;
      return result;
    }
  }

  return result;
}

function findSafeHeartbeatTarget() {
  const selectors = [
    "main",
    "[role='main']",
    ".learning-content",
    ".lesson-content",
    ".page-content",
    ".content",
    ".main-content",
    ".lms-layout",
    ".lms-container",
    "body"
  ];
  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      const el = doc.querySelector(sel);
      if (!el || !isVisible(el)) continue;
      const tag = String(el.tagName || "").toLowerCase();
      if (["a", "button", "input", "select", "textarea", "label"].includes(tag)) continue;
      return el;
    }
  }
  return null;
}

function dispatchSyntheticClick(target) {
  if (!target) return false;
  const rect = target.getBoundingClientRect ? target.getBoundingClientRect() : null;
  const x = rect ? Math.round(rect.left + Math.min(rect.width / 2, 40)) : 12;
  const y = rect ? Math.round(rect.top + Math.min(rect.height / 2, 16)) : 12;
  const base = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
  try {
    target.dispatchEvent(new MouseEvent("pointerdown", base));
  } catch {
    // ignore unsupported pointer event
  }
  try {
    target.dispatchEvent(new MouseEvent("mousedown", base));
    target.dispatchEvent(new MouseEvent("mouseup", base));
    target.dispatchEvent(new MouseEvent("click", base));
    return true;
  } catch {
    return false;
  }
}

function forceActivateElement(el) {
  if (!el) return false;
  try {
    el.scrollIntoView({ block: "center", inline: "center" });
  } catch {
    // ignore
  }
  try {
    el.focus({ preventScroll: true });
  } catch {
    // ignore
  }
  try {
    el.click();
    // Some ATI/Knockout controls only react to full pointer sequence.
    dispatchSyntheticClick(el);
    try {
      el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
      el.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", bubbles: true, cancelable: true }));
    } catch {
      // ignore keyboard dispatch failures
    }
    return true;
  } catch {
    return dispatchSyntheticClick(el);
  }
}

function invokeKnockoutClick(el) {
  if (!el) return false;
  try {
    const win = el.ownerDocument?.defaultView || window;
    const ko = win?.ko;
    if (!ko?.contextFor) return false;
    const ctx = ko.contextFor(el);
    if (!ctx) return false;
    const handlers = [ctx.$data, ctx.$parent, ctx.$root];
    for (const h of handlers) {
      if (h && typeof h.LoadNextPage === "function") {
        h.LoadNextPage.call(h);
        return true;
      }
    }
  } catch {
    // ignore KO call failures
  }
  return false;
}

function triggerSafeHeartbeatClick() {
  const now = nowMs();
  if (now - Number(STATE.lastSafeClickAt || 0) < 18000) {
    return { clicked: false, targetTag: "", targetClass: "", reason: "cooldown" };
  }
  const target = findSafeHeartbeatTarget();
  if (!target) {
    return { clicked: false, targetTag: "", targetClass: "", reason: "no-target" };
  }
  const clicked = dispatchSyntheticClick(target);
  if (clicked) {
    STATE.lastSafeClickAt = now;
  }
  return {
    clicked,
    targetTag: String(target.tagName || "").toLowerCase(),
    targetClass: String(target.className || "").slice(0, 80),
    reason: clicked ? "ok" : "dispatch-failed"
  };
}

function findSessionWarningContinueButton() {
  for (const doc of getSearchDocuments()) {
    const direct =
      doc.querySelector("button.btn-yes[aria-label*='continue where i left off' i]") ||
      doc.querySelector("button[aria-label*='continue where i left off' i]") ||
      doc.querySelector("button.btn-yes");
    if (direct && isVisible(direct)) {
      const directText = textNorm(
        (direct.textContent || "") +
        " " + (direct.getAttribute("aria-label") || "")
      );
      if (/continue where i left off|yes[, ]*continue/i.test(directText)) {
        return direct;
      }
    }
  }

  const warningPatterns = [
    /session/i,
    /expired/i,
    /time\s*out/i,
    /stay signed in/i,
    /continue session/i
  ];
  const continuePatterns = [
    /continue/i,
    /continue where i left off/i,
    /yes[, ]*continue where i left off/i,
    /where i left off/i,
    /stay signed in/i,
    /keep (me )?signed in/i,
    /resume/i
  ];

  for (const doc of getSearchDocuments()) {
    const candidates = [
      ...doc.querySelectorAll("button, a[role='button'], input[type='button'], input[type='submit']")
    ].filter((el) => isVisible(el));

    for (const el of candidates) {
      const text = textNorm(
        (el.textContent || "") +
        " " + (el.getAttribute("aria-label") || "") +
        " " + (el.getAttribute("title") || "") +
        " " + (el.getAttribute("value") || "")
      );
      if (!text) continue;
      if (!continuePatterns.some((rx) => rx.test(text))) continue;

      const modal = el.closest("[role='dialog'], .modal, .dialog, .popup, [class*='modal'], [class*='dialog']");
      if (!modal || !isVisible(modal)) continue;
      const modalText = textNorm(modal.textContent || "");
      const warningContext = warningPatterns.some((rx) => rx.test(modalText));
      const welcomeBackContext = /welcome back/i.test(modalText);
      if (!warningContext && !welcomeBackContext) continue;
      return el;
    }
  }
  return null;
}

async function dismissSessionWarningIfPresent() {
  // Keep-alive quiz/video/popup modes should not auto-interact with page dialogs.
  if (isVideoCaseProfile() || isAssessmentProfile() || isPopupCaseProfile()) return false;
  const now = nowMs();
  if (now - Number(STATE.lastSessionWarningDismissAt || 0) < 15000) {
    return false;
  }
  const btn = findSessionWarningContinueButton();
  if (!btn) return false;
  try {
    const clicked = forceActivateElement(btn);
    if (!clicked) {
      await reportProgress("session-warning-dismiss-failed");
      return false;
    }
    STATE.lastSessionWarningDismissAt = now;
    await reportProgress("session-warning-dismissed", {
      warningButtonText: String(btn.textContent || btn.getAttribute("value") || "").trim().slice(0, 80)
    });
    return true;
  } catch {
    await reportProgress("session-warning-dismiss-failed");
    return false;
  }
}

function nudgeAssessmentSessionTimers() {
  if (!isAssessmentProfile()) return { resetPosted: false };
  let resetPosted = false;
  const ATI_ORIGINS = [
    "https://assessments.atitesting.com",
    "https://student.atitesting.com",
    "https://lms.atitesting.com",
    "https://vcs.atitesting.com",
    "https://scorm.atitesting.com"
  ];

  function postReset(win) {
    if (!win) return false;
    let posted = false;
    // Prefer a known ATI origin over "*" so other sites cannot observe the message.
    for (const origin of ATI_ORIGINS) {
      try {
        win.postMessage("ResetTimer", origin);
        posted = true;
      } catch {
        // ignore
      }
    }
    return posted;
  }

  try {
    if (window.parent && window.parent !== window) {
      if (postReset(window.parent)) resetPosted = true;
    }
  } catch {
    // ignore cross-frame post failures
  }
  try {
    const frame = document.getElementById("assessmentFrame");
    if (frame?.contentWindow) {
      if (postReset(frame.contentWindow)) resetPosted = true;
    }
  } catch {
    // ignore
  }
  return { resetPosted };
}

async function triggerKeepAliveTouch({ allowScroll = true, allowSafeClick = true } = {}) {
  const marker = getKeepAliveMarker();
  const stamp = String(nowMs());
  marker.setAttribute("data-lht-keepalive", stamp);
  marker.style.transform = marker.style.transform === "translateX(1px)" ? "translateX(0)" : "translateX(1px)";
  marker.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, cancelable: true, view: window }));
  marker.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
  marker.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
  document.dispatchEvent(new Event("visibilitychange", { bubbles: true }));
  window.dispatchEvent(new Event("focus"));

  let movement = { moved: false, moveType: "none", moveDelta: 0 };
  if (allowScroll) {
    const amplitude = 6 + Math.floor(Math.random() * 18); // 6..23px
    movement = await nudgeScrollAndRestore({ maxPixels: amplitude });
  }

  if (document.body && typeof document.body.focus === "function") {
    try {
      document.body.setAttribute("tabindex", "-1");
      document.body.focus({ preventScroll: true });
    } catch {
      // ignore focus failures
    }
  }

  const assessmentNudge = nudgeAssessmentSessionTimers();

  STATE.keepAliveTouchedAt = nowMs();
  const safeClick = allowSafeClick
    ? triggerSafeHeartbeatClick()
    : { clicked: false, targetTag: "", targetClass: "", reason: "disabled" };
  return { ...movement, safeClick, assessmentResetPosted: !!assessmentNudge.resetPosted };
}

function computeNextPulseDelayMs(baseIntervalMs) {
  let factor = 0.6 + Math.random() * 0.9; // 60%..150%
  const roll = Math.random();
  if (roll < 0.1) factor += 0.25; // occasional longer pause
  else if (roll > 0.92) factor -= 0.18; // occasional quick follow-up
  return Math.max(12000, Math.round(baseIntervalMs * factor));
}

async function runKeepAliveLoop(token) {
  const baseIntervalMs = Math.max(
    15000,
    Number(STATE.settings.keepAliveIntervalSeconds || 45) * 1000
  );
  const preExpiryBufferMs = 4 * 60 * 1000; // avoid LMS "almost expired" warning window

  while (STATE.running && token === STATE.loopToken) {
    await dismissSessionWarningIfPresent();

    if (timerReached()) {
      if (isAssessmentProfile()) {
        const finalized = await tryFinalizeAssessmentOnTimerEnd();
        if (finalized) {
          toast("Timer reached. Finalizing Assessment.", "ok", 2000);
          STATE.running = false;
          notifyBackground("LHT_STOP");
          break;
        }
        // Finalize controls live in the quiz iframe; shell just stops quietly.
        if (!findAssessmentContinueButton() && !findFinalizeResultsButton()) {
          STATE.running = false;
          break;
        }
        toast("Timer reached. Could not finalize Assessment.", "warn", 2200);
        STATE.running = false;
        notifyBackground("LHT_STOP");
        break;
      }
      if (isPopupCaseProfile()) {
        const closed = await tryClosePopupCaseOnTimerEnd();
        if (closed) {
          toast("Timer reached. Closing Popup Case.", "ok", 1800);
          STATE.running = false;
          notifyBackground("LHT_STOP");
          break;
        }
        // CLOSE/doExit live on launchpage. Content pages must not LHT_STOP on miss
        // or they kill the session before launchpage can exit.
        if (!isPopupCaseExitHost()) {
          STATE.running = false;
          break;
        }
        toast("Timer reached. Could not find CLOSE.", "warn", 2200);
        STATE.running = false;
        notifyBackground("LHT_STOP");
        break;
      }
      await tryCloseLmsOnTimerEnd();
      toast("Timer reached. Keep-alive stopped.", "ok", 2000);
      STATE.running = false;
      notifyBackground("LHT_STOP");
      break;
    }

    if (!isKeepAliveProfile() && Number.isFinite(STATE.lmsTokenExpMs) && STATE.lmsTokenExpMs > 0 && !STATE.lmsPreExpiryHandled) {
      const tokenRemainingMs = STATE.lmsTokenExpMs - nowMs();
      if (tokenRemainingMs > 0 && tokenRemainingMs <= preExpiryBufferMs) {
        STATE.lmsPreExpiryHandled = true;
        await reportProgress("lms-token-near-expiry", {
          tokenRemainingMs
        });

        if (STATE.settings.closeLmsOnTimerEnd) {
          const didClose = await tryCloseLmsOnTimerEnd();
          await reportProgress(didClose ? "lms-pre-expiry-close-clicked" : "lms-pre-expiry-close-missed", {
            tokenRemainingMs
          });
          if (didClose) {
            STATE.running = false;
            notifyBackground("LHT_STOP");
            break;
          }
        } else {
          toast(`LMS session may expire in ${formatDuration(tokenRemainingMs)}.`, "warn", 3200);
        }
      }
    }

    const keepAliveHostOk =
      (isVideoCaseProfile() || isAssessmentProfile() || isPopupCaseProfile())
        ? isAtiHost()
        : isLmsHost();
    if (!keepAliveHostOk) {
      await reportProgress("keepalive-offhost", {
        host: location.hostname
      });
      await wait(30000);
      continue;
    }

    const hidden = document.visibilityState === "hidden";
    const movement = await triggerKeepAliveTouch({
      allowScroll: !hidden,
      allowSafeClick: !(isVideoCaseProfile() || isAssessmentProfile() || isPopupCaseProfile())
    });
    await reportProgress(hidden ? "keepalive-hidden-touch" : "keepalive-touch", {
      keepAliveIntervalSeconds: STATE.settings.keepAliveIntervalSeconds,
      keepAliveTouchedAt: STATE.keepAliveTouchedAt,
      moved: movement.moved,
      moveType: movement.moveType,
      moveDelta: movement.moveDelta,
      safeClicked: !!movement.safeClick?.clicked,
      safeClickTargetTag: movement.safeClick?.targetTag || "",
      safeClickTargetClass: movement.safeClick?.targetClass || "",
      safeClickReason: movement.safeClick?.reason || "",
      assessmentResetPosted: !!movement.assessmentResetPosted,
      hidden
    });

    const nextIntervalMs = hidden
      ? (12000 + Math.floor(Math.random() * 6000)) // 12-18s while hidden
      : computeNextPulseDelayMs(baseIntervalMs);
    // Don't sleep past timer zero — otherwise Continue/Finalize waits for the next pulse.
    const remMs = remainingMs();
    const sleepMs = remMs > 0 ? Math.min(nextIntervalMs, remMs) : 0;
    console.info("[LHT] keepalive pulse", {
      href: location.href,
      remainingMs: remMs,
      moved: movement.moved,
      moveType: movement.moveType,
      moveDelta: movement.moveDelta,
      safeClicked: !!movement.safeClick?.clicked,
      safeClickTarget: movement.safeClick?.targetTag || "",
      safeClickReason: movement.safeClick?.reason || "",
      nextPulseMs: nextIntervalMs,
      sleepMs
    });
    await wait(sleepMs);
  }
}

async function runLoop(token) {
  while (STATE.running && token === STATE.loopToken) {
    if (!frameHasAutomationTargets()) {
      // Fallback for ATI pages where controls render with dynamic/obfuscated classes.
      const forced = await clickContinue();
      if (forced) {
        await reportProgress("forced-continue");
        await wait(900);
        continue;
      }
      await wait(900);
      continue;
    }

    const sig = pageSignature();
    const toc = isAtSecondLast();
    const rem = remainingMs();

    await reportProgress("step", { signature: sig });

    const questionPrompt = detectQuestionPrompt();
    if (questionPrompt) {
      await reportProgress("question-detected-stop", questionPrompt);
      toast("Question detected. Autoplay paused for manual answer.", "warn", 2600);
      STATE.running = false;
      notifyBackground("LHT_PAUSE");
      break;
    }

    // Hard timer stop: if the user-selected timer is reached before module end,
    // stop automation at the current page and let the user continue manually.
    if (timerReached()) {
      await tryCloseLmsOnTimerEnd();
      console.info("[LHT] timer reached, stopping automation", { href: location.href, sig });
      toast("Timer reached. Automation stopped here.", "ok", 2000);
      STATE.running = false;
      notifyBackground("LHT_STOP");
      break;
    }

    // Opportunistic ATI behavior: try to keep media playing and continue when available.
    const opportunisticVideo = findPlayableVideo();
    if (STATE.settings.autoplayMedia) {
      ensurePlayPressedForSig(sig);
      if (opportunisticVideo) {
        await ensureVideoPlaying(opportunisticVideo);
      }
    }
    const opportunisticContinue = await clickContinue();
    if (opportunisticContinue) {
      await wait(900);
      continue;
    }

    if (STATE.settings.holdAtSecondLast && toc.known && toc.atSecondLast && !timerReached()) {
      if (!STATE.gateToastShown) {
        toast(`Holding at second-last step. Time remaining: ${formatDuration(rem)}.`, "warn", 2600);
        STATE.gateToastShown = true;
      }
      await wait(1000);
      continue;
    }

    STATE.gateToastShown = false;

    if (toc.known && toc.atSecondLast && timerReached()) {
      if (STATE.settings.autoFinishAfterTimer) {
        const didClick = await clickContinue();
        if (didClick) {
          toast("Timer reached. Finishing module.", "ok", 1800);
          await wait(1800);
        }
      } else {
        toast("Timer reached. Ready for manual final step.", "ok", 2200);
      }
      STATE.running = false;
      break;
    }

    const video = findPlayableVideo();
    const hasDurationLabel = Number.isFinite(findMediaDurationSeconds());
    if (video) {
      markMediaStartForSig(sig);
      if (STATE.settings.autoplayMedia) ensurePlayPressedForSig(sig);
      await ensureVideoPlaying(video);
      const done = await waitForVideoDone(video, token);
      if (!STATE.running || token !== STATE.loopToken) break;

      if (!done) {
        await wait(1000);
        continue;
      }

      await wait(450);
      const didClick = await clickContinue();
      if (!didClick) {
        await wait(1000);
      }
      await wait(1000);
      continue;
    }

    if (hasDurationLabel) {
      if (STATE.settings.autoplayMedia) ensurePlayPressedForSig(sig);
      const doneByLabel = await waitByDurationLabel(sig, token);
      if (!STATE.running || token !== STATE.loopToken) break;
      if (doneByLabel) {
        const didClick = await clickContinue();
        if (!didClick) await wait(1000);
        await wait(1000);
        continue;
      }
    }

    const dwellMs = Math.max(2000, Number(STATE.settings.fallbackPageSeconds || 5) * 1000);
    await wait(dwellMs);

    if (!STATE.running || token !== STATE.loopToken) break;

    const newSig = pageSignature();
    const samePage = sig === newSig;
    const enoughGap = nowMs() - STATE.lastContinueAt > 1500;
    if (samePage && enoughGap) {
      const didClick = await clickContinue();
      if (!didClick) {
        await wait(1200);
      }
    }
  }

  if (token === STATE.loopToken) {
    await reportProgress("stopped", { reason: "loop-end" });
  }
}

function start(payload) {
  if (STATE.running && Number(STATE.endAt || 0) > nowMs()) {
    // Prevent duplicate start re-inits from rapid session syncs.
    if (payload?.settings) {
      STATE.settings = { ...STATE.settings, ...payload.settings };
    }
    if (Number(payload?.endAt) > nowMs()) {
      STATE.endAt = Number(payload.endAt);
    }
    renderCountdownBadge();
    return;
  }

  STATE.running = true;
  STATE.startedAt = Number(payload?.startedAt) || nowMs();
  STATE.endAt = Number(payload?.endAt) || (STATE.startedAt + 30 * 60 * 1000);
  STATE.settings = { ...STATE.settings, ...(payload?.settings || {}) };
  STATE.loopToken += 1;
  STATE.lastContinueAt = 0;
  STATE.gateToastShown = false;
  STATE.mediaStartBySig = Object.create(null);
  STATE.playPressBySig = Object.create(null);
  STATE.keepAliveTouchedAt = 0;
  STATE.lastSignature = pageSignature();
  STATE.lmsPreExpiryHandled = false;
  const tokenInfo = getLmsTokenInfoFromLocation();
  STATE.lmsTokenExpMs = Number(tokenInfo?.expMs) || 0;
  startCountdownBadge();
  startModalWatchdog();
  console.info("[LHT] start", {
    href: location.href,
    isTop: IS_TOP,
    hasTargets: frameHasAutomationTargets(),
    endAt: STATE.endAt
  });
  if (IS_TOP) {
    if (isAssessmentProfile()) {
      toast("Assessment hold timer on. Finish the quiz yourself; at time-up we Continue → Finalize.", "ok", 2600);
    } else if (isPopupCaseProfile()) {
      toast("Popup Case timer on. Keep-alive only; CLOSE when time is up.", "ok", 2200);
    } else if (isVideoCaseProfile()) {
      toast("Video Case timer running (keep-alive only).", "ok", 1500);
    } else if (STATE.settings.keepAliveOnly) {
      toast("Keep-alive timer running.", "ok", 1500);
    } else {
      toast("ITA Lecture Assist Timer running.", "ok", 1500);
    }
  }

  if (isKeepAliveProfile()) {
    runKeepAliveLoop(STATE.loopToken);
    return;
  }

  // Kick playback immediately on Start so user doesn't need to click play manually.
  const sig = pageSignature();
  if (STATE.settings.autoplayMedia) {
    ensurePlayPressedForSig(sig);
    markMediaStartForSig(sig);
  }

  runLoop(STATE.loopToken);
}

function pause() {
  if (!STATE.running) return;
  STATE.running = false;
  STATE.loopToken += 1;
  stopCountdownBadge();
  stopModalWatchdog();
  if (IS_TOP) toast("Timer paused.", "info", 1200);
}

function findAssessmentContinueButton() {
  const selectors = [
    "button#moveNext.move-to-next-content-active",
    "button#moveNext",
    "button.move-to-next-content-active",
    "button[aria-label*='continue to next question' i]",
    "button[aria-label*='continue' i].move-to-next-content"
  ];
  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      const nodes = doc.querySelectorAll(sel);
      for (const el of nodes) {
        if (!isVisible(el)) continue;
        if (el.matches("[disabled], [aria-disabled='true']")) continue;
        const id = String(el.id || "").toLowerCase();
        const cls = String(el.className || "").toLowerCase();
        const txt = textNorm(
          `${el.textContent || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""}`
        );
        if (
          id === "movenext" ||
          cls.includes("move-to-next-content-active") ||
          /continue to next question/.test(txt)
        ) {
          return el;
        }
      }
    }
  }
  return null;
}

function findFinalizeResultsButton() {
  const selectors = [
    "button",
    "a",
    "[role='button']",
    "input[type='button']",
    "input[type='submit']"
  ];
  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      const nodes = doc.querySelectorAll(sel);
      for (const el of nodes) {
        if (!isVisible(el)) continue;
        if (el.matches("[disabled], [aria-disabled='true']")) continue;
        const txt = textNorm(
          `${el.textContent || ""} ${el.value || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""}`
        );
        // Prefer exact finalize CTA; avoid matching unrelated "view results" links.
        if (/finalize and view results/.test(txt) || (/finalize/.test(txt) && /results/.test(txt))) {
          return el;
        }
      }
    }
  }
  return null;
}

function isPopupCaseExitHost() {
  // Real Life close/exit is owned by the SCORM launchpage shell.
  return isScormHost() && /launchpage\.html/i.test(location.pathname || "");
}

function findPopupCaseCloseButton() {
  const selectors = [
    "a[onclick*='doExit']",
    "button[onclick*='doExit']",
    "[onclick*='doExit']",
    "#closeButton",
    "#btnClose",
    "#close",
    ".close-button",
    "div.rightjustified",
    ".rightjustified",
    "a.close",
    "button.close",
    "div.close",
    "span.close",
    "a[aria-label*='close' i]",
    "button[aria-label*='close' i]",
    "[aria-label*='close' i]",
    "img[alt*='close' i]",
    "header a",
    "header button",
    "header [role='button']",
    ".header a",
    ".header button",
    "#header a",
    "#header button",
    "a",
    "button",
    "[role='button']"
  ];
  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      let nodes;
      try {
        nodes = doc.querySelectorAll(sel);
      } catch {
        continue;
      }
      for (const el of nodes) {
        if (!isVisible(el)) continue;
        const txt = textNorm(
          `${el.textContent || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""} ${el.getAttribute("alt") || ""}`
        );
        const onclick = String(el.getAttribute("onclick") || "");
        const idClass = textNorm(`${el.id || ""} ${el.className || ""}`);
        if (/doExit/i.test(onclick)) return el;
        if (/(^|\b)(close|btnclose|closebutton)(\b|$)/.test(idClass) && txt.length <= 40) return el;
        // Header control is usually "CLOSE" or "X CLOSE".
        if (/^x?\s*close$/.test(txt) || (/close/.test(txt) && txt.length <= 16 && !/disclosure|enclosed|closet/.test(txt))) {
          return el;
        }
      }
    }
  }
  return null;
}

function tryInvokePopupCaseExit() {
  const windows = [];
  try { windows.push(window); } catch { /* ignore */ }
  try { if (window.parent) windows.push(window.parent); } catch { /* ignore */ }
  try { if (window.top) windows.push(window.top); } catch { /* ignore */ }

  for (const w of windows) {
    try {
      if (w && typeof w.doExit === "function") {
        w.doExit();
        return true;
      }
    } catch {
      // ignore cross-frame access failures
    }
  }

  // Same-origin contentFrame pages can still reach launchpage via frameElement owner.
  try {
    const owner = window.frameElement?.ownerDocument?.defaultView;
    if (owner && typeof owner.doExit === "function") {
      owner.doExit();
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

function findLmsCloseButton() {
  if (isPopupCaseProfile()) {
    return findPopupCaseCloseButton();
  }

  if (isVideoCaseProfile()) {
    const videoCaseSelectors = [
      "a.close-button[data-bind*='CloseVideoCaseStudy2Modules']",
      "a.close-button",
      "a[aria-label*='close' i]",
      "button[aria-label*='close' i]"
    ];
    for (const doc of getSearchDocuments()) {
      for (const sel of videoCaseSelectors) {
        const el = doc.querySelector(sel);
        if (!el || !isVisible(el)) continue;
        const txt = textNorm(
          `${el.textContent || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""}`
        );
        if (/close|exit|leave/.test(txt) || /CloseVideoCaseStudy2Modules/i.test(String(el.getAttribute("data-bind") || ""))) {
          return el;
        }
      }
    }
  }

  const selectors = [
    "a.close-lms",
    ".close-lms",
    ".close-lesson",
    ".close-module",
    "a[aria-label*='close lms' i]",
    "a[aria-label*='close lms application' i]",
    "a[aria-label*='close application' i]",
    "a[aria-label*='close lesson' i]",
    "a[aria-label*='exit' i]",
    "a[aria-label*='close' i].close-lms",
    "a.close-lms[tabindex='0']",
    ".close-container",
    "button[aria-label*='close lms' i]",
    "button[aria-label*='close application' i]",
    "button[aria-label*='close lesson' i]",
    "button[aria-label*='exit' i]",
    "[role='button'][aria-label*='close' i]",
    "[role='button'][aria-label*='exit' i]"
  ];
  for (const doc of getSearchDocuments()) {
    for (const sel of selectors) {
      const el = doc.querySelector(sel);
      if (el && isVisible(el)) return el;
    }
    const clickable = doc.querySelectorAll("a, button, [role='button']");
    for (const el of clickable) {
      if (!isVisible(el)) continue;
      const txt = textNorm(
        `${el.textContent || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""}`
      );
      if (/\b(close|exit|leave)\b/.test(txt) && /\b(lms|lesson|module|application)\b/.test(txt)) {
        return el;
      }
    }
  }
  return null;
}

async function tryFinalizeAssessmentOnTimerEnd() {
  // Intended start point: last answered question with Continue active.
  // Flow: Continue (show answer if needed) -> Continue -> Finalize and View Results.
  if (!STATE.settings.closeLmsOnTimerEnd) return false;

  for (let attempt = 0; attempt < 14; attempt += 1) {
    const finalizeBtn = findFinalizeResultsButton();
    if (finalizeBtn) {
      const clicked = forceActivateElement(finalizeBtn);
      if (clicked) {
        await reportProgress("timer-end-finalize-clicked", {
          closeTargetClass: String(finalizeBtn.className || "").slice(0, 100),
          closeTargetTag: String(finalizeBtn.tagName || "").toLowerCase(),
          closeAttempt: attempt + 1,
          closeStep: "finalize-results"
        });
        return true;
      }
    }

    const continueBtn = findAssessmentContinueButton();
    if (continueBtn) {
      const clicked = forceActivateElement(continueBtn);
      await reportProgress("timer-end-continue-clicked", {
        closeTargetClass: String(continueBtn.className || "").slice(0, 100),
        closeTargetTag: String(continueBtn.tagName || "").toLowerCase(),
        closeAria: String(continueBtn.getAttribute("aria-label") || "").slice(0, 100),
        closeAttempt: attempt + 1,
        closeStep: "continue",
        clicked: !!clicked
      });
      await wait(700);
      continue;
    }

    await wait(400);
  }

  await reportProgress("timer-end-finalize-not-found");
  return false;
}

async function tryClosePopupCaseOnTimerEnd() {
  if (!STATE.settings.closeLmsOnTimerEnd) return false;

  // Prefer SCORM exit API first — more reliable than hunting header chrome.
  for (let attempt = 0; attempt < 8; attempt += 1) {
    if (tryInvokePopupCaseExit()) {
      await reportProgress("timer-end-close-clicked", {
        closeAttempt: attempt + 1,
        closeStep: "doExit",
        href: String(location.href || "").slice(0, 180)
      });
      return true;
    }

    const closeBtn = findPopupCaseCloseButton();
    if (closeBtn) {
      const clicked = forceActivateElement(closeBtn);
      if (clicked) {
        await reportProgress("timer-end-close-clicked", {
          closeTargetClass: String(closeBtn.className || "").slice(0, 100),
          closeTargetTag: String(closeBtn.tagName || "").toLowerCase(),
          closeAttempt: attempt + 1,
          closeStep: "popup-close",
          href: String(location.href || "").slice(0, 180)
        });
        return true;
      }
    }
    await wait(350);
  }

  await reportProgress("timer-end-close-not-found", {
    href: String(location.href || "").slice(0, 180),
    isExitHost: isPopupCaseExitHost()
  });
  return false;
}

async function tryCloseLmsOnTimerEnd() {
  if (!STATE.settings.closeLmsOnTimerEnd) return false;
  if (isAssessmentProfile()) {
    return tryFinalizeAssessmentOnTimerEnd();
  }
  if (isPopupCaseProfile()) {
    return tryClosePopupCaseOnTimerEnd();
  }
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const closeBtn = findLmsCloseButton();
    if (closeBtn) {
      const clicked = forceActivateElement(closeBtn);
      if (clicked) {
        await reportProgress("timer-end-close-clicked", {
          closeTargetClass: String(closeBtn.className || "").slice(0, 100),
          closeTargetTag: String(closeBtn.tagName || "").toLowerCase(),
          closeAttempt: attempt + 1
        });
        toast(
          isVideoCaseProfile()
            ? "Timer reached. Closing Video Case page."
            : "Timer reached. Closing LMS page.",
          "ok",
          1800
        );
        return true;
      }
    }
    await wait(500);
  }
  await reportProgress("timer-end-close-not-found");
  return false;
}

function stop() {
  STATE.running = false;
  STATE.loopToken += 1;
  stopCountdownBadge();
  stopModalWatchdog();
  console.info("[LHT] stop", { href: location.href, isTop: IS_TOP });
  if (IS_TOP) toast("ITA Lecture Assist Timer stopped.", "info", 1200);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!shouldControlFrame()) {
    if (
      msg?.type === "LHT_START" ||
      msg?.type === "LHT_SYNC_SESSION" ||
      msg?.type === "LHT_STOP" ||
      msg?.type === "LHT_PAUSE" ||
      msg?.type === "LHT_RESUME"
    ) {
      sendResponse && sendResponse({ ok: true, passive: true });
      return false;
    }
    return false;
  }

  if (msg?.type === "LHT_START") {
    console.info("[LHT] received LHT_START", {
      href: location.href,
      isTop: IS_TOP,
      controlFrame: shouldControlFrame(),
      hasTargets: frameHasAutomationTargets()
    });
    start(msg.payload || {});
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === "LHT_SYNC_SESSION") {
    const nextEndAt = Number(msg?.payload?.endAt || 0);
    const wasRunning = STATE.running;
    STATE.startedAt = Number(msg?.payload?.startedAt) || STATE.startedAt;
    STATE.settings = { ...STATE.settings, ...(msg?.payload?.settings || {}) };

    // A past endAt from settings rewrite must never trigger Continue/Finalize.
    if (wasRunning && nextEndAt > 0 && nextEndAt <= nowMs() && !msg?.payload?.paused) {
      STATE.endAt = nextEndAt;
      stop();
      notifyBackground("LHT_STOP");
      if (IS_TOP) toast("Timer stopped after settings change.", "warn", 1800);
      sendResponse && sendResponse({ ok: true, stoppedForStaleEndAt: true });
      return false;
    }

    if (nextEndAt > 0) STATE.endAt = nextEndAt;
    if (msg?.payload?.paused) {
      pause();
    } else if (nextEndAt > nowMs()) {
      // Session sync on tab/frame updates should restart loop when not paused.
      start(msg.payload || {});
    }
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === "LHT_STOP") {
    stop();
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === "LHT_PAUSE") {
    pause();
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === "LHT_RESUME") {
    start(msg.payload || {});
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === "LHT_TIMER_EXPIRED") {
    STATE.startedAt = Number(msg?.payload?.startedAt) || STATE.startedAt;
    STATE.endAt = Number(msg?.payload?.endAt) || STATE.endAt;
    STATE.settings = { ...STATE.settings, ...(msg?.payload?.settings || {}) };
    let closePromise = Promise.resolve(false);
    if (isAssessmentProfile()) {
      closePromise = tryFinalizeAssessmentOnTimerEnd();
    } else if (isPopupCaseProfile()) {
      // Prefer launchpage; content frames only attempt parent.doExit and must not
      // block the exit host with a long failed button hunt.
      closePromise = isPopupCaseExitHost()
        ? tryClosePopupCaseOnTimerEnd()
        : Promise.resolve(tryInvokePopupCaseExit());
    } else {
      closePromise = tryCloseLmsOnTimerEnd();
    }
    closePromise.finally(() => {
      stop();
    });
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  return false;
});

// If popup already started the run on this tab before this script fully initialized,
// recover active session state immediately.
try {
  if (!shouldControlFrame()) {
    throw new Error("passive-frame");
  }
  chrome.runtime.sendMessage({ type: "LHT_GET_STATUS" }, (resp) => {
    if (chrome.runtime.lastError) return;
    const status = deriveRunningFromPayload(resp);
    if (!status?.running) return;
    if (status?.paused) return;
    if (Number(status.endAt || 0) <= nowMs()) return;
    start({
      startedAt: status.startedAt,
      endAt: status.endAt,
      settings: status.settings
    });
  });
} catch {
  // ignore bootstrap status failures
}
