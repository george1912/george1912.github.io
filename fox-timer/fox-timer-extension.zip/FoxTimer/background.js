// ITA Lecture Assist Timer - background service worker

const DEFAULT_SETTINGS = {
  contentProfile: "atiLesson",
  durationMinutes: 30,
  keepAliveOnly: false,
  keepAliveIntervalSeconds: 45,
  closeLmsOnTimerEnd: true,
  holdAtSecondLast: true,
  autoplayMedia: true,
  fallbackPageSeconds: 5,
  autoFinishAfterTimer: true
};

const SESSION_KEY = "lhtSession";
const DEBUG_LOG_KEY = "lhtDebugLog";
const MAX_DEBUG_ENTRIES = 600;
const POWER_KEEP_AWAKE_LEVEL = "display";
const SESSION_TICK_ALARM = "lht-session-tick";
const COMPANION_WINDOW_KEY = "lhtCompanionWindowId";

let accountabilityEnabled = false;
let accountabilityTabId = null;
let lastMousePos = { screenX: 0, screenY: 0, at: 0, source: "" };

const ATI_TAB_URLS = [
  "https://student.atitesting.com/*",
  "https://assessments.atitesting.com/*",
  "https://lms.atitesting.com/*",
  "https://vcs.atitesting.com/*",
  "https://scorm.atitesting.com/*"
];

async function findAtiTabId(preferredId) {
  const candidates = [];
  if (preferredId) candidates.push(Number(preferredId));
  if (runtimeSession.tabId) candidates.push(Number(runtimeSession.tabId));

  for (const id of candidates) {
    if (!Number.isFinite(id) || id <= 0) continue;
    try {
      const tab = await chrome.tabs.get(id);
      if (isAtiPageUrl(tab?.url)) return id;
    } catch {
      // try next candidate
    }
  }

  const tabs = await chrome.tabs.query({ url: ATI_TAB_URLS });
  const active = tabs.find((t) => t.active);
  return active?.id ?? tabs[0]?.id ?? null;
}

async function setAccountabilityTracking(enabled, tabIdOverride) {
  accountabilityEnabled = !!enabled;

  if (!accountabilityEnabled) {
    lastMousePos = { screenX: 0, screenY: 0, at: 0, source: "" };
    accountabilityTabId = null;
    return { ok: true, tabId: null };
  }

  accountabilityTabId = await findAtiTabId(tabIdOverride);
  if (!accountabilityTabId) {
    return { ok: false, error: "Open an ATI page in Chrome first, then turn on accountability mode." };
  }

  try {
    await chrome.tabs.sendMessage(accountabilityTabId, {
      type: "LHT_SET_ACCOUNTABILITY",
      enabled: true
    });
  } catch {
    // Content script may still be loading; companion will keep polling.
  }
  return { ok: true, tabId: accountabilityTabId };
}

let runtimeSession = {
  running: false,
  paused: false,
  pausedAt: 0,
  tabId: null,
  startedAt: 0,
  endAt: 0,
  settings: { ...DEFAULT_SETTINGS },
  lastReport: null,
  lastSyncedAt: 0
};

function nowMs() {
  return Date.now();
}

function isAtiPageUrl(url) {
  return /^https:\/\/(student|assessments|lms|vcs|scorm)\.atitesting\.com\//i.test(String(url || ""));
}

function clampDuration(mins) {
  const n = Number(mins);
  if (!Number.isFinite(n)) return DEFAULT_SETTINGS.durationMinutes;
  return Math.max(1, Math.min(24 * 60, Math.round(n)));
}

function normalizeSettings(input) {
  const next = { ...DEFAULT_SETTINGS, ...(input || {}) };
  next.contentProfile = ["atiLesson", "videoCase", "assessment", "popupCase"].includes(String(next.contentProfile))
    ? String(next.contentProfile)
    : DEFAULT_SETTINGS.contentProfile;
  next.durationMinutes = clampDuration(next.durationMinutes);
  next.keepAliveOnly = !!next.keepAliveOnly;
  next.closeLmsOnTimerEnd = !!next.closeLmsOnTimerEnd;
  next.holdAtSecondLast = !!next.holdAtSecondLast;
  next.autoplayMedia = !!next.autoplayMedia;
  next.autoFinishAfterTimer = !!next.autoFinishAfterTimer;

  const keepAliveEvery = Number(next.keepAliveIntervalSeconds);
  next.keepAliveIntervalSeconds = Number.isFinite(keepAliveEvery)
    ? Math.max(15, Math.min(300, Math.round(keepAliveEvery)))
    : DEFAULT_SETTINGS.keepAliveIntervalSeconds;

  const fallback = Number(next.fallbackPageSeconds);
  next.fallbackPageSeconds = Number.isFinite(fallback)
    ? Math.max(2, Math.min(120, Math.round(fallback)))
    : DEFAULT_SETTINGS.fallbackPageSeconds;
  return next;
}

function getSync(keys = DEFAULT_SETTINGS) {
  return new Promise((resolve) => {
    try {
      chrome.storage.sync.get(keys, (res) => resolve(res || keys));
    } catch {
      resolve(keys);
    }
  });
}

function setSync(values) {
  return new Promise((resolve) => {
    try {
      chrome.storage.sync.set(values, () => resolve());
    } catch {
      resolve();
    }
  });
}

function getLocal(keys) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(keys, (res) => resolve(res || keys));
    } catch {
      resolve(keys);
    }
  });
}

function setLocal(values) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.set(values, () => resolve());
    } catch {
      resolve();
    }
  });
}

/** Drop query/hash so registration IDs and tokens are not kept in debug logs. */
function sanitizeUrl(raw) {
  try {
    const u = new URL(String(raw || ""));
    const host = String(u.hostname || "").toLowerCase();
    if (!host.endsWith(".atitesting.com") && host !== "atitesting.com") {
      return "";
    }
    return `${u.origin}${u.pathname}`.slice(0, 180);
  } catch {
    return "";
  }
}

async function saveSession() {
  await setLocal({ [SESSION_KEY]: runtimeSession });
}

async function appendDebugLog(entry) {
  const data = await getLocal({ [DEBUG_LOG_KEY]: [] });
  const log = Array.isArray(data[DEBUG_LOG_KEY]) ? data[DEBUG_LOG_KEY] : [];
  const next = { ...(entry || {}) };
  if (Object.prototype.hasOwnProperty.call(next, "url")) {
    next.url = sanitizeUrl(next.url);
  }
  if (next.report && typeof next.report === "object") {
    next.report = { ...next.report };
    if (Object.prototype.hasOwnProperty.call(next.report, "url")) {
      next.report.url = sanitizeUrl(next.report.url);
    }
    if (Object.prototype.hasOwnProperty.call(next.report, "href")) {
      next.report.href = sanitizeUrl(next.report.href);
    }
  }
  log.push(next);
  if (log.length > MAX_DEBUG_ENTRIES) {
    log.splice(0, log.length - MAX_DEBUG_ENTRIES);
  }
  await setLocal({ [DEBUG_LOG_KEY]: log });
}

async function requestKeepAwake() {
  try {
    chrome.power.requestKeepAwake(POWER_KEEP_AWAKE_LEVEL);
    await appendDebugLog({
      at: nowMs(),
      event: "power-request-keep-awake",
      level: POWER_KEEP_AWAKE_LEVEL
    });
  } catch {
    await appendDebugLog({
      at: nowMs(),
      event: "power-request-failed",
      level: POWER_KEEP_AWAKE_LEVEL
    });
  }
}

async function releaseKeepAwake() {
  try {
    chrome.power.releaseKeepAwake();
    await appendDebugLog({
      at: nowMs(),
      event: "power-release-keep-awake"
    });
  } catch {
    await appendDebugLog({
      at: nowMs(),
      event: "power-release-failed"
    });
  }
}

async function restoreSession() {
  const data = await getLocal({ [SESSION_KEY]: null });
  const restored = data[SESSION_KEY];
  if (!restored || typeof restored !== "object") return;
  runtimeSession = {
    running: !!restored.running,
    paused: !!restored.paused,
    pausedAt: Number(restored.pausedAt) || 0,
    tabId: Number.isFinite(restored.tabId) ? restored.tabId : null,
    startedAt: Number(restored.startedAt) || 0,
    endAt: Number(restored.endAt) || 0,
    settings: normalizeSettings(restored.settings),
    lastReport: restored.lastReport || null,
    lastSyncedAt: Number(restored.lastSyncedAt) || 0
  };

  if (runtimeSession.running && !runtimeSession.paused) {
    await requestKeepAwake();
    armSessionAlarm();
  }
}

function buildStatus() {
  const remainingMs = runtimeSession.running
    ? Math.max(
      0,
      Number(runtimeSession.endAt || 0) - (
        runtimeSession.paused
          ? Number(runtimeSession.pausedAt || nowMs())
          : nowMs()
      )
    )
    : 0;
  return {
    running: !!runtimeSession.running,
    paused: !!runtimeSession.paused,
    tabId: runtimeSession.tabId,
    startedAt: runtimeSession.startedAt,
    endAt: runtimeSession.endAt,
    remainingMs,
    settings: runtimeSession.settings,
    lastReport: runtimeSession.lastReport,
    nowMs: nowMs(),
    lastSyncedAt: runtimeSession.lastSyncedAt
  };
}

function isSessionExpired() {
  if (!runtimeSession.running) return false;
  if (runtimeSession.paused) return false;
  return nowMs() >= Number(runtimeSession.endAt || 0);
}

async function stopRunIfExpired() {
  if (!isSessionExpired()) return false;
  const tabId = runtimeSession.tabId;
  const shouldCloseTabOnExpire = !!runtimeSession.settings?.closeLmsOnTimerEnd;
  if (Number.isFinite(tabId)) {
    const delivered = await broadcastToAllFrames(tabId, {
      type: "LHT_TIMER_EXPIRED",
      payload: {
        startedAt: runtimeSession.startedAt,
        endAt: runtimeSession.endAt,
        settings: runtimeSession.settings
      }
    });
    await appendDebugLog({
      at: nowMs(),
      event: "timer-expired-notify",
      tabId,
      frames: delivered
    });
    // Give the content script enough time to locate and click LMS Close / finalize.
    await new Promise((resolve) => setTimeout(resolve, 3200));

    // Fallback: close the active ATI tab if user opted into close-on-expire.
    // Skip for Popup Case — CLOSE/doExit already shuts the SCORM window and ATI
    // redirects; force-removing the tab can race that and leave Products/Home broken.
    const profile = String(runtimeSession.settings?.contentProfile || "");
    const skipTabCloseFallback = profile === "popupCase";
    if (shouldCloseTabOnExpire && !skipTabCloseFallback) {
      try {
        await chrome.tabs.remove(tabId);
        await appendDebugLog({
          at: nowMs(),
          event: "timer-expired-close-tab-fallback",
          tabId
        });
      } catch {
        // Ignore close-tab fallback failures.
      }
    } else if (skipTabCloseFallback) {
      await appendDebugLog({
        at: nowMs(),
        event: "timer-expired-skip-tab-close-fallback",
        tabId,
        profile
      });
    }
  }
  await appendDebugLog({
    at: nowMs(),
    event: "session-expired-auto-stop"
  });
  await stopRun();
  return true;
}

function armSessionAlarm() {
  try {
    chrome.alarms.create(SESSION_TICK_ALARM, { periodInMinutes: 1 });
  } catch {
    // ignore alarm failures
  }
}

function disarmSessionAlarm() {
  try {
    chrome.alarms.clear(SESSION_TICK_ALARM);
  } catch {
    // ignore alarm failures
  }
}

async function broadcastToAllFrames(tabId, payload) {
  const delivered = [];
  try {
    const frames = await chrome.webNavigation.getAllFrames({ tabId });
    for (const f of frames || []) {
      try {
        await chrome.tabs.sendMessage(tabId, payload, { frameId: f.frameId });
        delivered.push(f.frameId);
      } catch {
        // Ignore frame delivery failures.
      }
    }
  } catch {
    // ignore and fall through to generic tab-level delivery
  }
  if (!delivered.length) {
    try {
      await chrome.tabs.sendMessage(tabId, payload);
      delivered.push(0);
    } catch {
      // ignore
    }
  }
  return delivered;
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs[0] ? tabs[0] : null;
}

async function startRunOnActiveTab(settingsOverride) {
  const tab = await getActiveTab();
  if (!tab || !tab.id) throw new Error("No active tab");
  if (!isAtiPageUrl(tab.url)) {
    throw new Error("Focus the ATI page (or SCORM popup window), then press Play.");
  }

  const synced = await getSync(DEFAULT_SETTINGS);
  const settings = normalizeSettings({ ...synced, ...(settingsOverride || {}) });
  const startedAt = nowMs();
  const endAt = startedAt + settings.durationMinutes * 60 * 1000;

  runtimeSession = {
    running: true,
    paused: false,
    pausedAt: 0,
    tabId: tab.id,
    startedAt,
    endAt,
    settings,
    lastReport: null,
    lastSyncedAt: 0
  };
  await saveSession();
  await requestKeepAwake();
  armSessionAlarm();

  const frames = await broadcastToAllFrames(tab.id, {
    type: "LHT_START",
    payload: {
      startedAt,
      endAt,
      settings
    }
  });

  if (!frames.length) {
    await appendDebugLog({
      at: nowMs(),
      event: "start-no-controllable-frames",
      tabId: tab.id,
      url: sanitizeUrl(tab.url || "")
    });
    await stopRun();
    throw new Error("Could not attach to ATI page. Refresh the lesson page, then press Play.");
  }

  return { frames, ...buildStatus() };
}

async function stopRun() {
  const tabId = runtimeSession.tabId;
  runtimeSession.running = false;
  runtimeSession.paused = false;
  runtimeSession.pausedAt = 0;
  runtimeSession.tabId = null;
  runtimeSession.lastReport = null;
  runtimeSession.lastSyncedAt = 0;
  await saveSession();
  await releaseKeepAwake();
  disarmSessionAlarm();

  if (Number.isFinite(tabId)) {
    const delivered = await broadcastToAllFrames(tabId, { type: "LHT_STOP" });
    await appendDebugLog({
      at: nowMs(),
      event: "session-stopped",
      tabId,
      frames: delivered
    });
  }
  return buildStatus();
}

async function pauseRun() {
  if (!runtimeSession.running || runtimeSession.paused) {
    return buildStatus();
  }
  const tabId = runtimeSession.tabId;
  runtimeSession.paused = true;
  runtimeSession.pausedAt = nowMs();
  await saveSession();
  await releaseKeepAwake();
  disarmSessionAlarm();

  if (Number.isFinite(tabId)) {
    const delivered = await broadcastToAllFrames(tabId, { type: "LHT_PAUSE" });
    await appendDebugLog({
      at: nowMs(),
      event: "pause-delivered",
      tabId,
      frames: delivered
    });
  }
  await appendDebugLog({
    at: nowMs(),
    event: "session-paused",
    tabId: Number.isFinite(tabId) ? tabId : null
  });
  return buildStatus();
}

async function resumeRun() {
  if (!runtimeSession.running || !runtimeSession.paused) {
    return buildStatus();
  }
  const resumedAt = nowMs();
  const pausedForMs = Math.max(0, resumedAt - Number(runtimeSession.pausedAt || resumedAt));
  runtimeSession.startedAt += pausedForMs;
  runtimeSession.endAt += pausedForMs;
  runtimeSession.paused = false;
  runtimeSession.pausedAt = 0;
  await saveSession();
  await requestKeepAwake();
  armSessionAlarm();

  if (Number.isFinite(runtimeSession.tabId)) {
    const delivered = await broadcastToAllFrames(runtimeSession.tabId, {
      type: "LHT_RESUME",
      payload: {
        startedAt: runtimeSession.startedAt,
        endAt: runtimeSession.endAt,
        settings: runtimeSession.settings
      }
    });
    await appendDebugLog({
      at: nowMs(),
      event: "resume-delivered",
      tabId: runtimeSession.tabId,
      frames: delivered
    });
    if (!delivered.length) {
      await appendDebugLog({
        at: nowMs(),
        event: "resume-no-controllable-frames",
        tabId: runtimeSession.tabId
      });
      throw new Error("Could not resume on ATI page. Refresh the lesson page, then press Play.");
    }
  }
  await appendDebugLog({
    at: nowMs(),
    event: "session-resumed",
    tabId: Number.isFinite(runtimeSession.tabId) ? runtimeSession.tabId : null,
    pausedForMs
  });
  return buildStatus();
}

chrome.runtime.onInstalled.addListener(() => {
  setSync(DEFAULT_SETTINGS);
});

chrome.runtime.onStartup.addListener(() => {
  restoreSession();
});

restoreSession();

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-run") return;
  if (runtimeSession.running) {
    await stopRun();
    return;
  }
  try {
    await startRunOnActiveTab();
  } catch {
    // ignore command failures
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (!runtimeSession.running) return;
  if (runtimeSession.tabId !== tabId) return;
  await stopRun();
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!runtimeSession.running) return;
  if (runtimeSession.tabId !== tabId) return;
  if (changeInfo.status !== "complete") return;
  if (await stopRunIfExpired()) return;

  const url = String(changeInfo.url || tab?.url || "");
  if (!/^https:\/\/(student|assessments|lms|vcs|scorm)\.atitesting\.com\//i.test(url)) return;

  const syncedAt = nowMs();
  runtimeSession.lastSyncedAt = syncedAt;
  await saveSession();

  await appendDebugLog({
    at: nowMs(),
    event: "tab-updated-sync",
    tabId,
    url: sanitizeUrl(url)
  });

  await broadcastToAllFrames(tabId, {
    type: "LHT_SYNC_SESSION",
    payload: {
      startedAt: runtimeSession.startedAt,
      endAt: runtimeSession.endAt,
      settings: runtimeSession.settings,
      paused: runtimeSession.paused
    }
  });

});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm?.name !== SESSION_TICK_ALARM) return;
  if (!runtimeSession.running) return;
  if (runtimeSession.paused) return;
  if (await stopRunIfExpired()) return;
  if (!runtimeSession.running || runtimeSession.paused) return;

  await requestKeepAwake();
  if (!runtimeSession.running || runtimeSession.paused) return;
  await appendDebugLog({
    at: nowMs(),
    event: "session-heartbeat",
    remainingMs: Math.max(0, runtimeSession.endAt - nowMs())
  });

  // Self-heal: resync content scripts on each heartbeat.
  if (Number.isFinite(runtimeSession.tabId)) {
    const syncDelivered = await broadcastToAllFrames(runtimeSession.tabId, {
      type: "LHT_SYNC_SESSION",
      payload: {
        startedAt: runtimeSession.startedAt,
        endAt: runtimeSession.endAt,
        settings: runtimeSession.settings,
        paused: runtimeSession.paused
      }
    });
    await appendDebugLog({
      at: nowMs(),
      event: "heartbeat-sync",
      tabId: runtimeSession.tabId,
      frames: syncDelivered
    });

    // If content reports went stale, force a hard restart message.
    // Skip this in keep-alive/video-case mode to avoid noisy restarts.
    const lastReportAt = Number(runtimeSession.lastReport?.at || 0);
    const staleMs = nowMs() - lastReportAt;
    const keepAliveProfiles = ["videoCase", "assessment", "popupCase"];
    const shouldForceStart = !runtimeSession.settings?.keepAliveOnly
      && !keepAliveProfiles.includes(String(runtimeSession.settings?.contentProfile || ""));
    if (shouldForceStart && (!lastReportAt || staleMs > 95000)) {
      const startDelivered = await broadcastToAllFrames(runtimeSession.tabId, {
        type: "LHT_START",
        payload: {
          startedAt: runtimeSession.startedAt,
          endAt: runtimeSession.endAt,
          settings: runtimeSession.settings
        }
      });
      await appendDebugLog({
        at: nowMs(),
        event: "heartbeat-force-start",
        tabId: runtimeSession.tabId,
        staleMs,
        frames: startDelivered
      });
    }
  }
});

async function openCompanionWindow() {
  const companionUrl = chrome.runtime.getURL("companion.html");
  const stored = await getLocal({ [COMPANION_WINDOW_KEY]: null });
  const existingId = Number(stored[COMPANION_WINDOW_KEY]);

  if (Number.isFinite(existingId) && existingId > 0) {
    try {
      const win = await chrome.windows.get(existingId);
      if (win?.id) {
        await chrome.windows.update(existingId, { focused: true });
        return { ok: true, windowId: existingId, focused: true };
      }
    } catch {
      // Window gone — open a fresh one below.
    }
  }

  const created = await chrome.windows.create({
    url: companionUrl,
    type: "popup",
    width: 440,
    height: 720,
    focused: true
  });
  const windowId = created?.id ?? null;
  if (windowId != null) {
    await setLocal({ [COMPANION_WINDOW_KEY]: windowId });
  }
  return { ok: true, windowId, focused: false };
}

chrome.windows.onRemoved.addListener((windowId) => {
  getLocal({ [COMPANION_WINDOW_KEY]: null }).then((stored) => {
    if (Number(stored[COMPANION_WINDOW_KEY]) === windowId) {
      setLocal({ [COMPANION_WINDOW_KEY]: null });
    }
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg?.type) {
    case "LHT_GET_SETTINGS": {
      (async () => {
        const synced = await getSync(DEFAULT_SETTINGS);
        sendResponse({ ok: true, settings: normalizeSettings(synced) });
      })();
      return true;
    }

    case "LHT_SAVE_SETTINGS": {
      (async () => {
        const settings = normalizeSettings(msg?.settings);
        const prevDuration = Number(runtimeSession.settings?.durationMinutes);
        const durationChangedWhileRunning =
          !!runtimeSession.running &&
          Number(settings.durationMinutes) !== prevDuration;

        await setSync(settings);

        // Changing duration mid-run used to rewrite endAt from startedAt, which can
        // put the timer in the past and immediately fire finalize/close actions.
        // Stop cleanly instead and require Play for the new duration.
        if (durationChangedWhileRunning) {
          await appendDebugLog({
            at: nowMs(),
            event: "settings-duration-changed-stop",
            prevDuration,
            nextDuration: settings.durationMinutes,
            tabId: runtimeSession.tabId
          });
          await stopRun();
          sendResponse({ ok: true, settings, stoppedForDurationChange: true });
          return;
        }

        if (runtimeSession.running) {
          // Keep the existing endAt; only refresh non-duration settings.
          runtimeSession.settings = settings;
          await saveSession();
          if (Number.isFinite(runtimeSession.tabId)) {
            await broadcastToAllFrames(runtimeSession.tabId, {
              type: "LHT_SYNC_SESSION",
              payload: {
                startedAt: runtimeSession.startedAt,
                endAt: runtimeSession.endAt,
                settings,
                paused: runtimeSession.paused
              }
            });
          }
        }
        sendResponse({ ok: true, settings, stoppedForDurationChange: false });
      })();
      return true;
    }

    case "LHT_START": {
      (async () => {
        try {
          if (isSessionExpired()) {
            await stopRunIfExpired();
          }
          if (msg?.restart) {
            if (runtimeSession.running) {
              await stopRun();
            }
            const status = await startRunOnActiveTab(msg?.settings);
            sendResponse({ ok: true, status });
            return;
          }
          if (runtimeSession.running && !isSessionExpired()) {
            if (runtimeSession.paused) {
              const status = await resumeRun();
              sendResponse({ ok: true, status });
              return;
            }
            sendResponse({ ok: true, status: buildStatus() });
            return;
          }
          const status = await startRunOnActiveTab(msg?.settings);
          sendResponse({ ok: true, status });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_STOP": {
      (async () => {
        try {
          const status = await stopRun();
          sendResponse({ ok: true, status });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_PAUSE": {
      (async () => {
        try {
          if (!runtimeSession.running) {
            throw new Error("No active session to pause");
          }
          const status = await pauseRun();
          sendResponse({ ok: true, status });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_RESUME": {
      (async () => {
        try {
          if (!runtimeSession.running) {
            throw new Error("No active session to resume");
          }
          const status = await resumeRun();
          sendResponse({ ok: true, status });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_TOGGLE_PAUSE": {
      (async () => {
        try {
          if (!runtimeSession.running) {
            throw new Error("No active session to pause or resume");
          }
          const status = runtimeSession.paused
            ? await resumeRun()
            : await pauseRun();
          sendResponse({ ok: true, status });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_GET_STATUS": {
      (async () => {
        if (isSessionExpired()) {
          await stopRunIfExpired();
        }
        sendResponse({ ok: true, status: buildStatus() });
      })();
      return true;
    }

    case "LHT_PAGE_REPORT": {
      if (runtimeSession.running) {
        const safeUrl = sanitizeUrl(sender?.url || "");
        const report = { ...(msg.report || {}) };
        if (Object.prototype.hasOwnProperty.call(report, "href")) {
          report.href = sanitizeUrl(report.href);
        }
        if (Object.prototype.hasOwnProperty.call(report, "url")) {
          report.url = sanitizeUrl(report.url);
        }
        runtimeSession.lastReport = {
          at: nowMs(),
          url: safeUrl,
          ...report
        };
        saveSession();
        appendDebugLog({
          at: runtimeSession.lastReport.at,
          tabId: sender?.tab?.id ?? null,
          frameId: sender?.frameId ?? null,
          url: safeUrl,
          running: true,
          report: runtimeSession.lastReport
        });
      }
      sendResponse({ ok: true });
      return false;
    }

    case "LHT_GET_DEBUG_LOG": {
      (async () => {
        const data = await getLocal({ [DEBUG_LOG_KEY]: [] });
        const log = Array.isArray(data[DEBUG_LOG_KEY]) ? data[DEBUG_LOG_KEY] : [];
        sendResponse({ ok: true, log });
      })();
      return true;
    }

    case "LHT_CLEAR_DEBUG_LOG": {
      (async () => {
        await setLocal({ [DEBUG_LOG_KEY]: [] });
        sendResponse({ ok: true });
      })();
      return true;
    }

    case "LHT_OPEN_COMPANION": {
      (async () => {
        try {
          const result = await openCompanionWindow();
          sendResponse(result);
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_SET_ACCOUNTABILITY": {
      (async () => {
        try {
          const tabId = Number(msg?.tabId) || null;
          if (msg?.enabled) {
            const result = await setAccountabilityTracking(true, tabId);
            sendResponse(result);
            return;
          }
          if (accountabilityTabId) {
            try {
              await chrome.tabs.sendMessage(accountabilityTabId, {
                type: "LHT_SET_ACCOUNTABILITY",
                enabled: false
              });
            } catch {
              // ignore
            }
          }
          await setAccountabilityTracking(false);
          sendResponse({ ok: true, tabId: null });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
      })();
      return true;
    }

    case "LHT_GET_MOUSE_POS": {
      sendResponse({
        ok: true,
        pos: lastMousePos,
        stale: !lastMousePos.at || nowMs() - lastMousePos.at > 300
      });
      return false;
    }

    case "LHT_MOUSE_LEFT_PAGE": {
      lastMousePos = { screenX: lastMousePos.screenX, screenY: lastMousePos.screenY, at: 0, source: "" };
      return false;
    }

    case "LHT_MOUSE_POS": {
      lastMousePos = {
        screenX: Number(msg?.screenX) || 0,
        screenY: Number(msg?.screenY) || 0,
        at: nowMs(),
        source: String(msg?.source || "page")
      };
      return false;
    }

    default:
      return false;
  }
});
