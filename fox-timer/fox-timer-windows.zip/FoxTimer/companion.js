const headerTimeEl = document.getElementById("headerTime");
const runStatusEl = document.getElementById("runStatus");
const profileLabelEl = document.getElementById("profileLabel");
const filtersEl = document.getElementById("filters");
const tipCategoryEl = document.getElementById("tipCategory");
const tipTitleEl = document.getElementById("tipTitle");
const tipBodyEl = document.getElementById("tipBody");
const tipMetaEl = document.getElementById("tipMeta");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const regenBtn = document.getElementById("regenBtn");
const accountabilityBtn = document.getElementById("accountabilityBtn");
const eyesStageEl = document.getElementById("eyesStage");
const eyesHintEl = document.getElementById("eyesHint");

const PROFILE_LABELS = {
  atiLesson: "ATI Lesson",
  videoCase: "Video Case",
  assessment: "Assessment",
  popupCase: "Popup Case"
};

const CATEGORY_LABELS = Object.fromEntries(
  (globalThis.FoxStudyTips?.STUDY_TIP_CATEGORIES || []).map((c) => [c.id, c.label])
);

let activeCategory = "all";
let deck = [];
let index = 0;
let pollTimer = null;
let eyesAnimId = null;
let accountabilityOn = false;
let pointerOverBuddy = false;
let frozen = false;
let lastLook = { x: 0, y: 0 };

const eyeEls = Array.from(document.querySelectorAll(".cartoon-eye"));

function send(type, payload = {}) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage({ type, ...payload }, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else resolve(resp);
      });
    } catch (e) {
      reject(e);
    }
  });
}

function formatMs(ms) {
  const totalSec = Math.max(0, Math.ceil(Number(ms || 0) / 1000));
  const mins = Math.floor(totalSec / 60);
  const sec = totalSec % 60;
  return `${mins}:${String(sec).padStart(2, "0")}`;
}

function rebuildDeck({ preferRandom = false } = {}) {
  const tips = globalThis.FoxStudyTips?.tipsForCategory(activeCategory) || [];
  deck = tips.slice();
  if (!deck.length) {
    index = 0;
    renderTip();
    return;
  }
  if (preferRandom) {
    index = Math.floor(Math.random() * deck.length);
  } else {
    index = Math.min(index, deck.length - 1);
  }
  renderTip();
}

function renderFilters() {
  if (!filtersEl) return;
  const cats = globalThis.FoxStudyTips?.STUDY_TIP_CATEGORIES || [];
  filtersEl.innerHTML = "";
  for (const cat of cats) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "chip" + (cat.id === activeCategory ? " is-active" : "");
    btn.textContent = cat.label;
    btn.setAttribute("role", "tab");
    btn.setAttribute("aria-selected", cat.id === activeCategory ? "true" : "false");
    btn.addEventListener("click", () => {
      activeCategory = cat.id;
      renderFilters();
      rebuildDeck({ preferRandom: true });
    });
    filtersEl.appendChild(btn);
  }
}

function renderTip() {
  if (!deck.length) {
    if (tipCategoryEl) tipCategoryEl.textContent = "Tips";
    if (tipTitleEl) tipTitleEl.textContent = "No tips in this filter";
    if (tipBodyEl) tipBodyEl.textContent = "Try another topic or tap New tip.";
    if (tipMetaEl) tipMetaEl.textContent = "";
    return;
  }
  const tip = deck[index];
  if (tipCategoryEl) tipCategoryEl.textContent = CATEGORY_LABELS[tip.category] || tip.category;
  if (tipTitleEl) tipTitleEl.textContent = tip.title;
  if (tipBodyEl) tipBodyEl.textContent = tip.body;
  if (tipMetaEl) tipMetaEl.textContent = `${index + 1} of ${deck.length}`;
}

function step(delta) {
  if (!deck.length) return;
  index = (index + delta + deck.length) % deck.length;
  renderTip();
}

function regenerate() {
  if (!deck.length) {
    rebuildDeck({ preferRandom: true });
    return;
  }
  if (deck.length === 1) {
    renderTip();
    return;
  }
  let next = index;
  while (next === index) {
    next = Math.floor(Math.random() * deck.length);
  }
  index = next;
  renderTip();
}

function renderStatus(status) {
  const profile = PROFILE_LABELS[status?.settings?.contentProfile] || "";
  if (profileLabelEl) profileLabelEl.textContent = profile;

  if (!status?.running) {
    if (headerTimeEl) headerTimeEl.textContent = "--:--";
    if (runStatusEl) runStatusEl.textContent = "Timer idle — tips still work anytime.";
    return;
  }

  const remaining = formatMs(status.remainingMs);
  if (headerTimeEl) headerTimeEl.textContent = remaining;
  if (runStatusEl) {
    runStatusEl.textContent = status.paused
      ? `Paused · ${remaining} left`
      : `Running · ${remaining} left`;
  }
}

async function refreshStatus() {
  try {
    const resp = await send("LHT_GET_STATUS");
    if (resp?.ok) renderStatus(resp.status);
  } catch {
    // Companion can still show tips if messaging is briefly unavailable.
  }
}

function setFrozen(nextFrozen) {
  frozen = !!nextFrozen;
  if (eyesStageEl) eyesStageEl.classList.toggle("is-frozen", frozen);
}

function aimEyes(screenX, screenY) {
  let maxDx = 0;
  let maxDy = 0;

  for (const eyeEl of eyeEls) {
    const ball = eyeEl.querySelector(".eyeball");
    const pupil = eyeEl.querySelector(".pupil");
    const brow = eyeEl.querySelector(".brow");
    if (!ball || !pupil) continue;

    const rect = ball.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = screenX - cx;
    const dy = screenY - cy;
    const angle = Math.atan2(dy, dx);
    const dist = Math.min(11, Math.hypot(dx, dy) / 14);
    const px = Math.cos(angle) * dist;
    const py = Math.sin(angle) * dist;
    pupil.style.transform = `translate(${px}px, ${py}px)`;

    if (brow) {
      const tilt = Math.max(-18, Math.min(18, (dx / 120) * 18));
      brow.style.transform = `rotate(${tilt}deg)`;
    }

    maxDx = Math.max(maxDx, Math.abs(dx));
    maxDy = Math.max(maxDy, Math.abs(dy));
  }

  lastLook = { x: screenX, y: screenY };
  return { maxDx, maxDy };
}

async function pollPointerForEyes() {
  if (!accountabilityOn) return;

  if (!pointerOverBuddy) {
    try {
      const resp = await send("LHT_GET_MOUSE_POS");
      if (resp?.ok && resp.pos?.at && !resp.stale) {
        setFrozen(false);
        aimEyes(resp.pos.screenX, resp.pos.screenY);
      } else {
        setFrozen(true);
      }
    } catch {
      setFrozen(true);
    }
  }

  eyesAnimId = requestAnimationFrame(() => {
    pollPointerForEyes();
  });
}

document.addEventListener("mousemove", (e) => {
  if (!accountabilityOn) return;
  pointerOverBuddy = true;
  setFrozen(false);
  aimEyes(e.screenX, e.screenY);
});

document.addEventListener("mouseleave", () => {
  pointerOverBuddy = false;
  if (accountabilityOn) setFrozen(true);
});

async function setAccountability(on) {
  accountabilityOn = !!on;
  if (accountabilityBtn) {
    accountabilityBtn.classList.toggle("is-on", accountabilityOn);
    accountabilityBtn.textContent = accountabilityOn
      ? "Turn off accountability"
      : "Accountability mode";
  }
  if (eyesStageEl) {
    eyesStageEl.classList.toggle("is-visible", accountabilityOn);
    eyesStageEl.setAttribute("aria-hidden", accountabilityOn ? "false" : "true");
  }
  if (eyesHintEl) eyesHintEl.classList.toggle("is-visible", accountabilityOn);

  if (accountabilityOn) {
    setFrozen(false);
    try {
      await send("LHT_SET_ACCOUNTABILITY", { enabled: true });
    } catch {
      // Eyes still track inside this window.
    }
    if (!eyesAnimId) pollPointerForEyes();
  } else {
    try {
      await send("LHT_SET_ACCOUNTABILITY", { enabled: false });
    } catch {
      // ignore
    }
    if (eyesAnimId) {
      cancelAnimationFrame(eyesAnimId);
      eyesAnimId = null;
    }
    setFrozen(false);
  }
}

accountabilityBtn?.addEventListener("click", () => {
  setAccountability(!accountabilityOn);
});

prevBtn?.addEventListener("click", () => step(-1));
nextBtn?.addEventListener("click", () => step(1));
regenBtn?.addEventListener("click", regenerate);

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft") step(-1);
  if (e.key === "ArrowRight") step(1);
  if (e.key === "r" || e.key === "R") regenerate();
});

renderFilters();
rebuildDeck({ preferRandom: true });
refreshStatus();
pollTimer = setInterval(refreshStatus, 1000);

window.addEventListener("beforeunload", () => {
  if (pollTimer) clearInterval(pollTimer);
  if (eyesAnimId) cancelAnimationFrame(eyesAnimId);
  if (accountabilityOn) {
    send("LHT_SET_ACCOUNTABILITY", { enabled: false }).catch(() => {});
  }
});
