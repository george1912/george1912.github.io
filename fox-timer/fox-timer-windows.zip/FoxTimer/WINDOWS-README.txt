Windows tip
===========
This ZIP opens into a folder named FoxTimer.

1. Right-click the ZIP → Extract All…
2. Choose a place you’ll keep (Documents is fine)
3. In Chrome go to chrome://extensions
4. Turn on Developer mode
5. Click Load unpacked
6. Select the FoxTimer folder (the one that contains manifest.json)

Do not delete the FoxTimer folder after installing.
