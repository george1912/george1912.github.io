// Shared study-aid tips for popup + Study Board companion.
(function (root) {
  const STUDY_TIP_CATEGORIES = [
    { id: "all", label: "All" },
    { id: "methods", label: "Study methods" },
    { id: "time", label: "Time & breaks" },
    { id: "fuel", label: "Fuel & energy" },
    { id: "check", label: "Check learning" }
  ];

  const STUDY_TIPS = [
    {
      category: "methods",
      title: "Teach it back",
      body: "Explain one concept out loud like you’re teaching a classmate. Wherever you stumble becomes your next note."
    },
    {
      category: "methods",
      title: "Why it matters",
      body: "Under every key fact, write one line: why this matters for a patient or clinical decision."
    },
    {
      category: "methods",
      title: "Paraphrase, don’t highlight",
      body: "Turn one dense paragraph into 2–3 bullets in your own words. If you can’t rephrase it, you don’t own it yet."
    },
    {
      category: "methods",
      title: "Map before you dive",
      body: "Skim headings first, then go deep. See the forest before the trees so new details have a place to land."
    },
    {
      category: "methods",
      title: "Patient lens",
      body: "Connect this topic to a patient scenario — what would you assess first, and what would you watch for?"
    },
    {
      category: "methods",
      title: "Tiny mnemonic",
      body: "Make a short mnemonic for the hardest list on this page. Even a silly one sticks better than rereading."
    },
    {
      category: "time",
      title: "Protect the block",
      body: "Phone face-down for this timer. Notes and focus now — notifications after the block ends."
    },
    {
      category: "time",
      title: "25 / 5 rhythm",
      body: "Work a focused block, then take a real 5-minute break: stand, water, eyes off the screen. Restart fresh."
    },
    {
      category: "time",
      title: "One goal per block",
      body: "Set a mini goal before Play: “By the end of this timer, I can teach X.” One target beats vague studying."
    },
    {
      category: "time",
      title: "Question parking lot",
      body: "Mark fuzzy spots with a ? and keep moving. Review the ? list in the last 5 minutes of your block."
    },
    {
      category: "time",
      title: "Stand and reset",
      body: "Every so often: stand, stretch 20 seconds, then write one sentence summarizing the last section."
    },
    {
      category: "fuel",
      title: "Water first",
      body: "Start the block with water nearby. Mild dehydration quietly drains focus long before you feel thirsty."
    },
    {
      category: "fuel",
      title: "Steady fuel",
      body: "Prefer a light protein + complex carb snack (yogurt, nuts, fruit) over candy crashes mid-study."
    },
    {
      category: "fuel",
      title: "Don’t study starving",
      body: "If you’re running on empty, take 5 minutes to eat something simple before the next long block."
    },
    {
      category: "fuel",
      title: "Caffeine with a plan",
      body: "If you use caffeine, keep it early in your study window and pair it with water so energy stays even."
    },
    {
      category: "fuel",
      title: "Eyes and posture",
      body: "Sit tall, screen a bit below eye level, and blink on purpose. Comfort keeps attention longer than grind."
    },
    {
      category: "check",
      title: "60-second quiz",
      body: "Cover your notes and answer from memory for 60 seconds. Retrieval is how learning sticks."
    },
    {
      category: "check",
      title: "Three takeaways",
      body: "Before moving on, close your eyes and list 3 takeaways from the last section. Gaps show what to revisit."
    },
    {
      category: "check",
      title: "Brain dump finish",
      body: "End the block with a 90-second brain dump — no notes open. Whatever’s missing is tomorrow’s review list."
    },
    {
      category: "check",
      title: "Same / different",
      body: "Compare two related ideas side-by-side: what’s the same, what’s different, and why nurses care."
    },
    {
      category: "check",
      title: "Prove it",
      body: "Ask: “How would I know I understand this?” Then do that check — quiz, teach-back, or a quick scenario."
    },
    {
      category: "check",
      title: "Active question",
      body: "After each media clip, jot one question you still have — then hunt the answer before you move on."
    }
  ];

  function tipsForCategory(categoryId) {
    const id = String(categoryId || "all");
    if (id === "all") return STUDY_TIPS.slice();
    return STUDY_TIPS.filter((tip) => tip.category === id);
  }

  function plainTipBodies(categoryId) {
    return tipsForCategory(categoryId).map((tip) => tip.body);
  }

  root.FoxStudyTips = {
    STUDY_TIP_CATEGORIES,
    STUDY_TIPS,
    tipsForCategory,
    plainTipBodies
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
